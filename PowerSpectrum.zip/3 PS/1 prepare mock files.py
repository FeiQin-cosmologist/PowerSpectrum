import numpy as np
import math
import matplotlib.pyplot as plt
import scipy as sp
from scipy import integrate
from scipy import interpolate
from CosmoFunc import *
from FQin import *
from nb_CF4 import *
from astropy import units as u
from astropy.coordinates import SkyCoord

Cl=299792.458
OmegaM=0.3121
OmegaA=1.-OmegaM
Hub=100.

 

 


#survey_area = 2.0*math.pi*(1.0-np.cos(170.0/180.0*math.pi))  #  #  2.0*math.pi*(1.0-np.cos(80.0/180.0*math.pi))#0.63*math.pi
Shat  = 2.0*math.pi*(1.0-np.sin(38./180.0*math.pi))
Sbelt = 2.0*math.pi*(1.0-np.sin(10./180.0*math.pi)) - Shat









# 1: survey:-------------------------------------------------------------------
infile = np.loadtxt('/Users/fei/WSP/Scie/Proj6/Data/Prod/CF4_TF.txt')
ID       = infile[:,0]  ; ind_alf=np.where(ID==1)[0];ind_adt=np.where(ID==0)[0] 
Ra       = infile[:,1]   
Dec      = infile[:,2]
l        = infile[:,3]
b        = infile[:,4]
cz       = infile[:,5]
logd     = infile[:,6]
elogd    = infile[:,7]
i        = infile[:,8]
w1       = infile[:,9]
mu       = infile[:,10]
z      = cz /LightSpeed
ndata  = len(Ra );ndatasd=ndata
X_cf4,Y_cf4,Z_cf4 = Sky2Cat(Ra,Dec,z,OmegaM , OmegaA ,Hub,nbin=10000,redmax=0.16)


print('Ngal=',ndata)
nb= nb_cf4(Ra, Dec, z,OmegaM,OmegaA,Hub, 10000,0.3)
  
outfile = open('/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/CF4.txt', 'w')
outfile.write(" %18d\n"% (ndata))
outfile.write("#    ra      dec     cz     logdt     logd      elogd     nbar\n") 
for i in range(ndata):
    outfile.write(" %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf \n" % (Ra[i],Dec[i],cz[i],logd[i],elogd[i],nb[i]))                
outfile.close()
plt.figure(1)
plt.scatter(z,nb,s=0.1)


# 2: Mocks:--------------------------------------------------------------------
input_head_cf4 = '/Users/fei/WSP/Scie/Proj6/Data/Prod/CF4TFmocks/CF4TF_mock'
Imock=65
Jmock=8   
Nmock=Jmock*Imock
for i_mock in range(Imock):
  i_mock=i_mock+19000
  for j_mock in range(Jmock):
    input_dir = input_head_cf4+str(i_mock)+'.'+str(j_mock)
    data1_mock= np.loadtxt(input_dir)
    IDsmk  = data1_mock[:,0]
    Ramk   = data1_mock[:,1]
    Decmk  = data1_mock[:,2]
    czmk   = data1_mock[:,3];z=czmk/LightSpeed
    logdmkt= data1_mock[:,4]
    logdmk = data1_mock[:,5]
    elogdmk= data1_mock[:,6]
    Xmk,Ymk,Zmk = Sky2Cat(Ramk,Decmk,z,OmegaM , OmegaA ,Hub,nbin=10000,redmax=0.16)
    ndata=len(IDsmk)
    #print('Nmockgal=',ndata)
     
    nb= nb_cf4(Ramk, Decmk, z,OmegaM,OmegaA,Hub, 10000,0.3)
  
    outfile = open('/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/mocks/CF4_mock_'+str(i_mock)+'.'+str(j_mock), 'w')
    outfile.write(" %18d\n"% (ndata))
    outfile.write("# ID    ra      dec     cz     logdt     logd      elogd     nbar\n") 
    for i in range(ndata):
        outfile.write(" %18d  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n" % (int(i),Ramk[i],Decmk[i],czmk[i],logdmkt[i],logdmk[i],elogdmk[i],nb[i]))                
    outfile.close()
plt.figure(2)
plt.scatter(z,nb,s=0.1)
  

 
# 3: Randoms:------------------------------------------------------------------
infile =np.loadtxt('/Users/fei/WSP/Scie/Proj6/Data/Prod/random/CF4_rand.txt')
ndataR =len(infile[:,0])
Xr     =infile[:,0]
Yr     =infile[:,1]
Zr     =infile[:,2]
raR    =infile[:,3]
decR   =infile[:,4]
distR  =infile[:,5]
zR     =infile[:,6]

nbR= nb_cf4(raR, decR, zR,OmegaM,OmegaA,Hub, 10000,0.3)
nbR = nbR  * ( ndatasd / ndataR )

print('Nrand=',ndataR)  
output_dir = '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/rand_CF4.txt'
outfile    = open(output_dir, 'w')
outfile.write(" %18d\n"% (ndataR))
outfile.write("#   ra      dec     cz     nbar\n")
for i in range(ndataR):
    outfile.write(" %12.6lf  %12.6lf  %12.6lf  %12.6lf \n" % ( raR[i],decR[i],zR[i]*LightSpeed,nbR[i]))                
outfile.close()  
 
plt.figure(3)
plt.scatter(zR,nbR,s=0.1)
 
