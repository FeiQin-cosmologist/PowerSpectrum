#==========================================================================
#
#                              INTRODUCTION
#
#--------------------------------------------------------------------------

#  https://samreay.github.io/ChainConsumer/examples/index.html#basic-usages

# python /Users/fei/WSP/Scie/Proj3/Prog/4\ Result/8\ plot.py




#--------------------------------------------------------------------------
#                                  CODE
#--------------------------------------------------------------------------
# INITIAL SETTING:
import math
import numpy as np
from chainconsumer import ChainConsumer
import matplotlib.pyplot as plt
# color :  https://gist.github.com/tabahara/ffc64b76f65d483a6bbec4e91168fcbd
# https://samreay.github.io/ChainConsumer/examples/customisations/plot_contour_labels.html
# https://samreay.github.io/ChainConsumer/examples/customisations/plot_fewer_parameters.html




PS_type    =  'den+mom' #'mom' # 
Surveys    =  'real'  #'mock'#        
Nparms     =   5    # it must be 5 rather than 8!


mean  = [0.422893,-100 ] 
# 2. for den+mom-PS: ----------------------------------------------------------

for i_survey in range(1):
    output_MCMCchian  = '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/CF4_MOCK_MCMC_PSden+mom_mocks_chainCH.txt'
    data=np.loadtxt(output_MCMCchian)
    c = ChainConsumer().add_chain(data[:,0:2], parameters=["$f\sigma_8$","$b_1\sigma_8$"]) 
    c.configure(flip=False,  colors="#00bfa5",tick_font_size=15,label_font_size=18, cloud=True, sigma2d=True, sigmas=[1,1.5,2,2.5])
    fig = c.plotter.plot(figsize=(6, 6),filename='/Users/fei/WSP/Scie/Proj6/Results/den+mom_mock.png',truth=mean)
 



plt.show()
