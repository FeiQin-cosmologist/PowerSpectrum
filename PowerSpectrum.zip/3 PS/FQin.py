#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 20:20:08 2020

@author: fei.qin
"""


import numpy as np
import math
import matplotlib.pyplot as plt
import scipy as sp
from scipy.interpolate import splev, splrep
from astropy.cosmology import FlatLambdaCDM
from CosmoFunc import *
from astropy.coordinates import SkyCoord
from matplotlib import cm
from astropy import units as u
import mpmath as mp

# Speed of light in km/s
LightSpeed = 299792.458


def Arctan_sig(yp,xp):
    if(yp>=0.) and (xp==0):
        degrr=90.
    if(yp<=0.) and (xp==0):
        degrr=270.
    if(yp>=0.) and (xp>0.):
        degrr=180.0/np.pi*np.arctan(yp/xp)
    if(yp>=0.) and (xp<0.):
        degrr=180.0/np.pi*np.arctan(yp/xp)+180.
    if(yp<0.) and (xp<0.):
        degrr=180.0/np.pi*np.arctan(yp/xp)+180.
    if(yp<0.) and (xp>0.):
        degrr=180.0/np.pi*np.arctan(yp/xp)+360.
    return degrr

def Arctan(yp,xp): 
    yp1=np.asarray(yp)
    xp1=np.asarray(xp)
    rasgrid1=np.zeros((len(xp1),len(yp1),1))
    for i in range(len(xp1)):
        for j in range(len(yp1)):
            rasgrid1[i,j,:]=Arctan_sig(yp1[j],xp1[i])
    return rasgrid1

















def Gridding_data(xpos,ypos,zpos,nx,ny,nz,MINX,MAXX,MINY,MAXY,MINZ,MAXZ,weigt):
    dx  = np.abs(MAXX-MINX)/nx;   dy  = np.abs(MAXY-MINY)/ny;   dz  = np.abs(MAXZ-MINZ)/nz;
    datgrid,edges = np.histogramdd(np.vstack([xpos,ypos,zpos]).transpose(),bins=(nx,ny,nz),range=((MINX,MAXX),(MINY,MAXY),(MINZ,MAXZ)),weights=weigt)
    Numb,edge     = np.histogramdd(np.vstack([xpos,ypos,zpos]).transpose(),bins=(nx,ny,nz),range=((MINX,MAXX),(MINY,MAXY),(MINZ,MAXZ))              )
    return datgrid,Numb,edges,dx,dy,dz

def WinFUN_grid(nx,ny,nz,dx,dy,dz,Xmin,Ymin,Zmin,rmin,rmax,dmin,dmax,b_MKYplane,zmin,zmax,nbin_spl,redmax_spl,hulb,OmegaM):
    print('Window Function of Grid')
    x0,y0,z0 = -Xmin,-Ymin,-Zmin 
    xp = dx*np.arange(nx) - x0 + 0.5*dx
    yp = dy*np.arange(ny) - y0 + 0.5*dy
    rasgrid=Arctan(yp,xp)
    zp = dz*np.arange(nz) - z0 + 0.5*dz  
    xp,yp,zp=xp[:,np.newaxis,np.newaxis],yp[np.newaxis,:,np.newaxis],zp[np.newaxis,np.newaxis,:]  
    #rasgrid = 180.0/np.pi*np.arctan(yp/xp)+180.0
    decgrid = 180.0/np.pi*np.arctan(zp/np.sqrt(xp**2 + yp**2))  
    dist = np.sqrt(((xp)**2)+((yp)**2)+((zp)**2))
    cosmo = FlatLambdaCDM(H0=hulb,Om0=OmegaM)
    redarr = np.linspace(0.,redmax_spl,nbin_spl)
    distarr = cosmo.comoving_distance(redarr).value
    redgrid = np.interp(dist,distarr,redarr)   
    c = SkyCoord(ra=rasgrid, dec=decgrid, unit=(u.degree, u.degree))
    x = c.galactic
    l = np.asarray( x.l)
    b = np.asarray(x.b)
    cutgrid = (rasgrid > rmin) & (rasgrid < rmax) & (decgrid > dmin) & (decgrid < dmax) & (redgrid > zmin) & (redgrid < zmax) & ( np.abs(b)>=b_MKYplane )        
    wingrid = np.where(cutgrid,1.,0.)
    return wingrid,x0,y0,z0


















def SubSampling(Critc,ras,typesa):
    #print('SubSampling')
    Ndats=len(ras)
    raout=[]   
    indxss=[]
    if(typesa=='<='):
      for i in range(Ndats):
        tp=np.random.rand(1)
        if(tp<=Critc):        
            raout.append( (ras[i] ))
            indxss.append( ( int(i) ))
    if(typesa=='>='):
      for i in range(Ndats):
        tp=np.random.rand(1)
        if(tp>=Critc):        
            raout.append( (ras[i] ))
            indxss.append( ( int(i) ))        
    return raout,np.asarray(indxss)

def SubSampling_hist(Mag,Mag_cf4,NhistBin,ratio,typesa):
    num_cf4,bins_cf4= np.histogram(Mag_cf4,NhistBin) 
    num_hal,var     = np.histogram(Mag,bins=bins_cf4) 
    inddi           = np.digitize(Mag, bins_cf4)
    indfin          = []
    for i in range(len(num_cf4)):
        indssl    = np.where( inddi == (i+1))
        if(num_hal[i]>0):
          var,ind_z = SubSampling( ratio*num_cf4[i]/num_hal[i],Mag[indssl],typesa)
          if(len(ind_z)>0):
            tempind   = indssl[0][ind_z]
            for j in range(len(tempind)):
                indfin.append(  tempind[j] )
    indfin=np.asarray(  indfin  ) 
    return indfin

def SubSampling_3D(nx,ny,nz,minX,maxX,minY,maxY,minZ,maxZ, X_cf4,Y_cf4,Z_cf4,Xs   ,Ys   ,Zs,sigmas,facti=1.,typs='ratio',thres=0.):
    Grids_cf4  ,Numb_cf4  ,edges_cf4  ,dx,dy,dz= Gridding_data(X_cf4,Y_cf4,Z_cf4,nx,ny,nz,minX,maxX,minY,maxY,minZ,maxZ,np.ones(len(X_cf4)))
    Grids_halos,Numb_halos,edges_halos,dx,dy,dz= Gridding_data(Xs   ,Ys   ,Zs   ,nx,ny,nz,minX,maxX,minY,maxY,minZ,maxZ,np.ones(len(Xs))   )     
    Crit=np.zeros((nx,ny,nz))
    if(typs=='ratio'):
      for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                if(Grids_halos[i,j,k] > 0.) and (Grids_cf4[i,j,k] > 0. ):
                    Crit[i,j,k]=float(Grids_cf4[i,j,k])/float(Grids_halos[i,j,k])                         
    if(typs=='unif'):
      img = sp.ndimage.gaussian_filter(Grids_cf4, sigma=(sigmas[0], sigmas[1],sigmas[2]), order=0)
      for i in range(nx):
        for j in range(ny):
            for k in range(nz):
                if (img[i,j,k] > thres ):
                    Crit[i,j,k]=1.                  
    Crit=Crit*facti         
    ind_sub=[]
    for ipart in range(len(Xs)):
        ix=int((Xs[ipart]-minX)/dx); iy=int((Ys[ipart]-minY)/dy); iz=int((Zs[ipart]-minZ)/dz);
        if ix<0   :  ix=ix+nx;      
        if iy<0   :  iy=iy+ny;     
        if iz<0   :  iz=iz+nz;
        if ix>=nx :  ix=ix-nx;      
        if iy>=ny :  iy=iy-ny;     
        if iz>=nz :  iz=iz-nz;
        tp=np.random.rand(1)
        if(tp<=Crit[ix,iy,iz]):
            ind_sub.append( ( ipart ))
    ind_sub=np.asarray(ind_sub)
    ind_sub=ind_sub.T
    return ind_sub

















def spline_Dis2Rsf(OmegaM,OmegaA,Hub,nbin=10000,redmax=2.5):
    dist = np.empty(nbin);red = np.empty(nbin)
    for j in range(nbin):
        red[j] = j*redmax/nbin
        dist[j] = DistDc(red[j],OmegaM,OmegaA, 0.0,Hub,-1.0, 0.0, 0.0)
    rsf_spline = sp.interpolate.splrep(dist,red,  s=0)
    return rsf_spline

def spline_Rsf2Dis(OmegaM,OmegaA,Hub,nbin=10000,redmax=2.5):
    dist = np.empty(nbin);red = np.empty(nbin)
    for j in range(nbin):
        red[j] = j*redmax/nbin
        dist[j] = DistDc(red[j],OmegaM,OmegaA, 0.0,Hub,-1.0, 0.0, 0.0)
    dist_spline = sp.interpolate.splrep(red, dist, s=0)
    return dist_spline

def DisRsfConvert(xdt,types,OmegaM,OmegaA,Hub,nbin=10000,redmax=2.5):
    if(types=='z2d'):
        spl_fun=spline_Rsf2Dis(OmegaM,OmegaA,Hub,nbin,redmax)
        Distc        = splev(xdt, spl_fun)
        return Distc
    if(types=='d2z'):
        spl_fun=spline_Dis2Rsf(OmegaM,OmegaA,Hub,nbin,redmax)
        RSFs        = splev(xdt, spl_fun)
        return RSFs

def Sky2Cat(ra,dec,rsft,OmegaM , OmegaA ,Hub,nbin=1000,redmax=2.):
    disz= DisRsfConvert(rsft,'z2d',OmegaM,OmegaA,Hub,nbin,redmax)
    X = disz*np.cos(dec/180.*math.pi)*np.cos(ra/180.*math.pi)
    Y = disz*np.cos(dec/180.*math.pi)*np.sin(ra/180.*math.pi)
    Z = disz*np.sin(dec/180.*math.pi)    
    return X,Y,Z

def Sky_mollview(RA,Dec,cz,i_plts,org=0, projection='mollweide'):
    plt.figure(i_plts)
    ''' RA, Dec are arrays of the same length.
        RA takes values in [0,360), Dec in [-90,90],
        which represent angles in degrees.
        org is the origin of the plot, 0 or a multiple of 30 degrees in [0,360).
        title is the title of the figure.
        projection is the kind of projection: 'mollweide', 'aitoff', 'hammer', 'lambert'
        '''
    x = np.remainder(RA+360-org,360) # shift RA values
    ind = x>180
    x[ind] -=360    # scale conversion to [-180, 180]
    x=-x    # reverse the scale: East to the left
    
    fig = plt.figure(figsize=(10, 5))
    ax = fig.add_subplot(111, projection=projection)
    sc=ax.scatter(np.radians(x),np.radians(Dec),c=cz,vmin=min(cz), vmax=max(cz),s=5,cmap=cm.cool)  # convert degrees to radians
    # color : https://matplotlib.org/2.0.2/examples/color/colormaps_reference.html
    # x label:-------------
    tick_labels = np.array([150, 120, 90, 60, 30, 0, 330, 300, 270, 240, 210])
    tick_labels = np.remainder(tick_labels+360+org,360)
    ax.set_xticklabels(tick_labels)     # we add the scale on the x axis
    ax.set_xlabel("l  [degrees]")
    ax.xaxis.label.set_fontsize(12)
    # y label:-------------
    ticky_labels=[-75,-60,-45,-30,-15,0,15,30,45,60,75]
    ax.set_yticklabels(ticky_labels)
    ax.set_ylabel("b  [degrees]")
    ax.yaxis.label.set_fontsize(12)
    # grids:---------------
    ax.grid(True)
    cbar=plt.colorbar(sc, fraction=0.046, pad=0.04)
    cbar.set_label('cz  [ km/s ]')
    return i_plts




















def Common_gal(ra_2mtf,dec_2mtf,cz_2mtf,ra_cf3 ,dec_cf3,cz_cf3,dcz_cri ,dang_cri,iplt):
    #setting initial value:
    #dcz_cri  = 150. #km/s,  |cz(2mtf)-cz(cf4)|<150 km/s=dcz_cri.
    #dang_cri = 1./3600.*10. #|dec(2mtf)-dec(cf4)|<10" =dang_cri, |ra(2mtf)-ra(cf4)|<10"   =dang_cri.
    ind_2mtf=[]
    ind_cf3 =[]
    Ndata_2mtf=len(ra_2mtf)
    #calculate the distance between a 2mtf galaxy and a cf3 galaxies:
    for i in range(Ndata_2mtf):
        dcz = np.abs(cz_2mtf[i]-cz_cf3)#the redshift between a 2mtf galaxy and all the cf3 galaxies.
        ind = np.where(dcz <= dcz_cri)#find the index of the cf3 galaxies  which obey the |cz(2mtf)-cz(cf3GSv)|<150 km/s.
        if( len(ind[0]) > 0 ): # 'num' is the amount of the cf3 galaxies which obey the |cz(2mtf)-cz(cf3GSv)|<150 km/s.
            ra_cf3_commoncz  = ra_cf3[ind]
            dec_cf3_commoncz = dec_cf3[ind]
            dag=np.sqrt((dec_2mtf[i]-dec_cf3_commoncz)**2 +(ra_2mtf[i]-ra_cf3_commoncz)**2)
            #'dag' is the angular distance between a 2mtf galaxy and
            #those cf3 galaxies which obey |cz(2mtf)-cz(cf3GSv)|<150 km/s.
            indag=np.where(dag <= dang_cri )#find the index of the cf3
            #galaxies which obey |dec(2mtf)-dec(cf3GSv)|<10" and
            #|ra(2mtf)-ra(cf3GSv)|<10".'numag' is the amount of the cf3
            #galaxies which obey the criterias.
            if( len(indag[0])==1 ):                        
                ind_2mtf.append(  (int(i)) )     
                ind_cf3.append(  (     ind[0][indag[0]][0]     ))
            if( len(indag[0]) > 1 ):     
                ind_2mtf.append(  (int(i)) )
                indagp      = np.where(   dag[indag] == np.min(dag[indag])   )
                #if there are more than one cf3 galaxies obey the criterias,
                #choosing the cf3 galaxy which is closest to the given
                #2mtf galaxy.
                ind_cf3.append(       ind[0][indag[0][indagp]][0]      ) 
                 
    print('There are',len(ind_2mtf),'common galaxies.')           
    
    if(len(ind_2mtf)>0):  
        ind_2mtf = np.asarray(ind_2mtf)
        ind_cf3 = np.asarray(ind_cf3)

        plt.figure(iplt,figsize=(18, 18))  
        plt.scatter(ra_2mtf[ind_2mtf],dec_2mtf[ind_2mtf], marker='.')
        plt.scatter(ra_cf3[ind_cf3],dec_cf3[ind_cf3], s=40, facecolors='none', edgecolors='r')
        plt.xlabel('RA')
        plt.ylabel('DEC')
        
        plt.figure(iplt+1)  
        plt.scatter(cz_2mtf[ind_2mtf],cz_cf3[ind_cf3], marker='.')
        plt.plot(cz_cf3[ind_cf3],cz_cf3[ind_cf3], 'k')
 
    return ind_2mtf, ind_cf3
 
    
 
    
 
    
 
    
 
    
 
    
 
    
 
    
 
def Schecter_PDF(x, Schecter_norm, Schecter_Mk, Schecter_alpha):
    exponent = 0.4*(Schecter_Mk-x)
    p1 = 10.0**(exponent*(Schecter_alpha+1.0))
    p2 = math.exp(-10.0**exponent)
    return 0.4*math.log(10)*Schecter_norm*p1*p2

def Schecter_CDF(lower, upper, Schecter_norm, Schecter_Mk, Schecter_alpha):
    result = sp.integrate.quad(Schecter_PDF, lower, upper, args=(Schecter_norm, Schecter_Mk, Schecter_alpha), limit=100)[0]
    return result

def Schecter_CDFgama(upper,  Schecter_norm, Schecter_Mk, Schecter_alpha):
    #result = sp.integrate.quad(Schecter_PDF2, lower, upper, args=(Schecter_norm, Schecter_Mk, Schecter_alpha), limit=100)[0]
    lfaint = 10.0**(-float(upper)/2.5)
    lstar = 10.0**(-Schecter_Mk/2.5)
    result = Schecter_norm*mp.gammainc(Schecter_alpha+1.0,lfaint/lstar)
    return  result 
















def PDF_splfun(x2,consta,PDF_spl):
        y2 = splev(x2, PDF_spl)
        return y2
def CDF_x(x,xs,PDF_spl):
        consta=2
        Cum=integrate.quad(PDF_splfun, np.min(xs), x ,  epsabs=0.0,epsrel=1.0e-5,args=(consta,PDF_spl))[0]
        return Cum
def CDF_sampler(x_spl_pdf,y_spl_pdf,Nsamp):    
        Cdf=np.zeros(len(x_spl_pdf))
        PDF_spl=splrep(x_spl_pdf,y_spl_pdf,s=0)
        for i in range(len(x_spl_pdf)):
            Cdf[i]=CDF_x(x_spl_pdf[i],x_spl_pdf,PDF_spl)
        CDFx=np.random.random(Nsamp)*(np.max(Cdf)-np.min(Cdf))+np.min(Cdf)
        elogd_sample = np.interp(CDFx,Cdf,x_spl_pdf)  
        return elogd_sample












def nbar_compute(delt_z,zhR,survey_area,OmegaM,OmegaA,Hub,nbin=10000,redmax=2.3):
    Nz=int(np.abs(np.max(zhR)-np.min(zhR))/delt_z)
    Binz=np.zeros((Nz+2))
    for i in range(Nz+2):
        Binz[i]=np.min(zhR)+i*delt_z
    HIS=np.histogram(zhR,bins=Binz)
    N=HIS[0]
    B=HIS[1]
    #plt.scatter(B[:len(B)-1],N,c='r');plt.hist(zhR,51,alpha=0.3);
    Dz=DisRsfConvert(B,'z2d',OmegaM,OmegaA,Hub,nbin,redmax)
    spl_nbar  = np.array([0.]*(len(Dz)-1))
    for i in range(len(Dz)-1):
        Rin  = Dz[i]
        Rout = Dz[i+1]
        volume = (survey_area)*(Rout*Rout*Rout-Rin*Rin*Rin)/3.0 # survey_area in unit of pi not degree
        spl_nbar[i] = N[i]/volume;
    nbar_spline = sp.interpolate.splrep(Dz[0:len(Dz)-1] + np.abs(Dz[1]-Dz[2])/2.,spl_nbar, s=0)
    Dzs=DisRsfConvert(zhR,'z2d',OmegaM,OmegaA,Hub,nbin=10000,redmax=0.3)
    nbs=sp.interpolate.splev(Dzs, nbar_spline, der=0)
    return nbs

def  RandomSurvey(N_sample,Nprec,maxdis,RI,Typesu):
    if(Typesu == 'Exp'):
        spl_X=np.linspace(0,maxdis,Nprec);
        spl_Y=spl_X * spl_X *np.exp(-spl_X * spl_X/(2.*RI*RI));
    if(Typesu == 'Slop'):
        spl_X=np.linspace(0,maxdis,Nprec);
        spl_Y=spl_X * spl_X  ;
    if(Typesu == 'Unif'):
        spl_X=np.linspace(0,maxdis,Nprec);
        spl_Y=np.ones(len(spl_X))  ;
    # normlization
    Nom=0;
    for i in range(len(spl_X)-1):
        Nom=Nom+(spl_Y[i+1]+spl_Y[i] )*(spl_X[i+1]-spl_X[i])/2;
    spl_Y=spl_Y/Nom
    dist=CDF_sampler(spl_X,spl_Y,N_sample)
    # sky cover:
    U=np.random.rand(1,N_sample)*2-1;
    theta=np.random.rand(1,N_sample)*2*math.pi;
    X=np.sqrt(1.-U*U) * np.cos(theta);
    Y=np.sqrt(1.-U*U) * np.sin(theta);
    Z=U;
    longitude=2.*(math.pi/2.+np.arctan(Y/X))*180./math.pi;
    latitude=np.arcsin(Z)*180./math.pi;
    return longitude[0],latitude[0],dist











    
def Vpec_tra(Rsf,Logd,OmegaM,OmegaA, Hub,nbin,redmax):
    dz=DisRsfConvert(Rsf,'z2d',OmegaM,OmegaA,Hub,nbin,redmax)
    dh=dz*10.0**(-Logd)
    zh=DisRsfConvert(dh,'d2z',OmegaM,OmegaA,Hub,nbin,redmax)
    v=LightSpeed *( Rsf - zh )/( 1.0 + zh )
    return v

def Vpec_wat(Rsf,Logd,OmegaM,OmegaA, Hub):
    deccel = 3.0*OmegaM/2.0 - 1.0
    Vmod   = Rsf*LightSpeed*(1.0 + 0.5*(1.0 - deccel)*Rsf - (2.0 - deccel - 3.0*deccel*deccel)*Rsf*Rsf/6.0)
    vpec   = math.log(10.)*Vmod/(1.0+Vmod/LightSpeed) * Logd
    return vpec




