#==========================================================================
#
#                              INTRODUCTION
#
#--------------------------------------------------------------------------

# python /Users/fei/WSP/Scie/Proj3/Prog/2\ CF4/5\ CosmicParm_PS/4\ main\ fit\ param\ CH.py


#Hi Fei,

#I have attached the latest version of my paper, 
#and the copter power spectrum for Om=0.3121, sigma8=0.8150. 
#The columns in the copter file are: k, P_delta,delta, P_delta,theta, P_theta,theta.

#Thanks,
#Cullan 2018



#==========================================================================
#                           INITIAL SETTING
#--------------------------------------------------------------------------
# 1. INITIAL SETTING:
import math
import numpy as np
import scipy as sp
from scipy import interpolate
from scipy import stats
import matplotlib.pyplot as plt
import camb
from camb import model, initialpower
from CosmoFunc import *
from WFconv import * 
from ParamEstimateCH import *
from PLOT_PS import *



# 2. read in the PS of the CF4 data:--------------------------------------
domultipo         =   False  #True  #       
if(not domultipo):Nmultipo =    1# 2#  
if(domultipo):    Nmultipo =    2#      
WFCon_type        =   'Ross'   # 'Blake' #  
Damp_type         =   'unif'  #'sep'      #   
PS_measure        =   'mocks'    # 'survey'#
PS_type           =   'den+mom'   #'den+mom'      # 
strategy          =   'MCMC'  # 'Optimize' #  
fit_tech          =   'BC'    # 'Chi2'     #       
Nparms            =    5

NKs               =   40
fit_minK          =   0.02       
fit_maxK          =   0.3

nkj               =   1000        
Ncosa             =   200        # intigration precision
epsilon_par       =   [0.0,0.4,1000] # intigration precision and intervel

   


input_PS_dataden  =   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/CF4_den.txt'
input_PS_datamom  =   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/CF4_mom.txt' 
input_PS_mocksden =   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/mockPS/CF4_mock_den'
input_PS_mocksmom =   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/mockPS/CF4_mock_mom'
infile_PS_rand    =   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/rand_CF4_mom.txt'



outInteg_dir      =   '/Users/fei/WSP/Scie/Proj6/Data/Orig/INTEG_CH.txt'
output_MCMCchian  =   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/CF4_MOCK_MCMC_PS'+PS_type+'_'+PS_measure+'_chainCH.txt'
if(Nparms==8):
  output_MCMCchian=   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/CF4_MOCK_MCMC_PS_chainCH_P8.txt' 

if(WFCon_type=='Blake'):
    if(PS_type=='mom')or(PS_type=='den+mom'):
      input_WFcon =   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/CF4GSv_convmat.npy'
    if(PS_type=='den'):
      input_WFcon =   '/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/CF4GS_convmat.npy'
      



print( 'Please adjust the COV_kmax to make sure the')
print( 'WF-convolved-PS consistants with the')
print( 'unconvolved-PS at larger k-bins!')
print( 'CONV_kmax changes over fit_maxK,Damp_type,PS_measure and PS_type')
#The PS of the real 2MTF survey has some over fit problems'
# in damping sigma_v, it is normal to see the convolved-PS slighlty do not '
#consistants with the unconvolved-PS at larger k-bins!'
if(Damp_type == 'unif'):CONV_kmax = 0.42 # this number is only for (den+mom or mom) and unif
CONV_kmax=0.42
print( 'CONV_kmax =',CONV_kmax)
print( ' ')

#==========================================================================
#                               MAIN CODE
# 1. read data:------------------------------------------------------------
if(PS_type=='den')or(PS_type=='den+mom'):
   infile_PS_dataden  = input_PS_dataden
   infile_PS_mocksden = input_PS_mocksden
if(PS_type=='mom')or(PS_type=='den+mom'):
   infile_PS_datamom  = input_PS_datamom
   infile_PS_mocksmom = input_PS_mocksmom
# 1.1: linear PS (if using fortran CAMB, set do_nonlinear=0): 
pars = camb.CAMBparams()
pars.set_cosmology(H0=67.27,ombh2=0.022, omch2=0.1198)
pars.set_dark_energy() #re-set defaults
pars.InitPower.set_params(As=2.114940245149156e-09,ns=0.9645)
pars.set_matter_power(redshifts=[0.], kmax=100.0)
pars.NonLinear = model.NonLinear_none
results = camb.get_results(pars)
khs, z, pks = results.get_matter_power_spectrum(minkh=1e-4, maxkh=100.0, npoints = 692) 
Sig8_fid = results.get_sigma8()[0]
Pk_linear=pks[0,:]
k_linear=khs
print( 'sigma8_fid = ',Sig8_fid)
plt.figure(1)
plt.plot(np.log10(k_linear),np.log10(Pk_linear),color='k')
plt.title('CAMB-linear PS')
# 1.2: WF of the random catloge:-----------------------
 
infile=np.loadtxt(infile_PS_rand)
k_rand=infile[0:len(infile[:,0])-1,1]
Pk_rand=infile[0:len(infile[:,0])-1,2]
k_rand[0]=0.0
Pk_rand[0]=1.0
ind=np.where(Pk_rand>0.0)
k_rand =k_rand[ind]
Pk_rand =Pk_rand[ind]
plt.figure(2)
ind=np.where(Pk_rand>0.0)
k_rand =k_rand[ind]
Pk_rand =Pk_rand[ind]
plt.plot(np.log10(k_rand[1:len(k_rand)]),np.log10(Pk_rand[1:len(k_rand)]),color='b')
plt.title('random-PS')

ktemp,Pktemp=PS_extender(k_rand[1:len(k_rand)],Pk_rand[1:len(k_rand)],100,len(k_rand))
k_rands =np.zeros(1+len(ktemp));Pk_rands=np.zeros(1+len(ktemp))
k_rands[0]=0.0;Pk_rands[0]=1.0
k_rands[1:len(k_rands)]=ktemp;Pk_rands[1:len(k_rands)]=Pktemp
k_rand=k_rands
Pk_rand=Pk_rands
ind=np.where(Pk_rand>0.0)
k_rand =k_rand[ind]
Pk_rand =Pk_rand[ind]
plt.plot(np.log10(k_rand[1:len(k_rand)]),np.log10(Pk_rand[1:len(k_rand)]),color='r')

# 1.3: PS of survey data:-----------------------------
if(PS_type=='mom'):
    infile=np.loadtxt(infile_PS_datamom)
    k_data=infile[0:len(infile[:,0])-1,1]
    Pk_data=infile[0:len(infile[:,0])-1,2]
    if(domultipo):
        k_data=np.concatenate([infile[0:len(infile[:,0])-1,1],infile[0:len(infile[:,0])-1,1]])
        Pk_data=np.concatenate([infile[0:len(infile[:,0])-1,2],infile[0:len(infile[:,0])-1,3]])
if(PS_type=='den'):
    infile=np.loadtxt(infile_PS_dataden)
    k_data=infile[0:len(infile[:,0])-1,1]
    Pk_data=infile[0:len(infile[:,0])-1,2]
    if(domultipo):
        k_data=np.concatenate([infile[0:len(infile[:,0])-1,1],infile[0:len(infile[:,0])-1,1]])
        Pk_data=np.concatenate([infile[0:len(infile[:,0])-1,2],infile[0:len(infile[:,0])-1,3]])
if(PS_type=='den+mom'):
    if(not domultipo):
        infile=np.loadtxt(infile_PS_dataden)
        k_data=infile[0:len(infile[:,0])-1,1]
        Pk_data=np.zeros((2*len(k_data)))
        Pk_data[0:len(k_data)]=infile[0:len(infile[:,0])-1,2]
        infile=np.loadtxt(infile_PS_datamom)
        Pk_data[len(k_data):2*len(k_data)]=infile[0:len(infile[:,0])-1,2]
    if(domultipo):
        infileD=np.loadtxt(infile_PS_dataden)
        infileM=np.loadtxt(infile_PS_datamom)
        k_data=np.concatenate([infileD[0:len(infile[:,0])-1,1],infileD[0:len(infile[:,0])-1,1],infileD[0:len(infile[:,0])-1,1],infileD[0:len(infile[:,0])-1,1]])
        Pk_data=np.concatenate([infileD[0:len(infile[:,0])-1,2],infileD[0:len(infile[:,0])-1,3],infileM[0:len(infile[:,0])-1,2],infileM[0:len(infile[:,0])-1,3]])
# 1.4: PS of mocks:-----------------------------------
Imock=65  
Jmock=8    ;
NSS=NKs-1#-14+1 ;#0.01 between 0.02 and 0.25, so 23 points
Nmock=Imock*Jmock;                                             
if(not domultipo):Pg0_mock=np.zeros((NSS,Nmock))
if(domultipo):Pg0_mock=np.zeros((Nmultipo*NSS,Nmock))
if(PS_type=='den+mom'):
    if(not domultipo):
        Pg0_mock=np.zeros((2*NSS,Nmock))  
    if(domultipo):
        Pg0_mock=np.zeros((2*Nmultipo*NSS,Nmock))  
k=0;
for i_mock in range(Imock):
  i_mock=i_mock+19000
  for j_mock in range(Jmock): 
    if(PS_type=='mom'):  
        inputfile_dir=infile_PS_mocksmom+str(i_mock)+'.'+str(j_mock)    
        infile= np.loadtxt(inputfile_dir)
        if(not domultipo):
            NO=infile[0:len(infile[:,0])-1,0]
            kp_mock=infile[0:len(infile[:,0])-1,1]  
            Pg0_mock[:,k]=infile[0:len(infile[:,0])-1,2]  
        if(domultipo):
            kp_mock       = np.concatenate([infile[0:len(infile[:,0])-1,1],infile[0:len(infile[:,0])-1,1]])
            Pg0_mock[:,k] = np.concatenate([infile[0:len(infile[:,0])-1,2],infile[0:len(infile[:,0])-1,3]])      
    if(PS_type=='den'):
        inputfile_dir=infile_PS_mocksden+str(i_mock)+'.'+str(j_mock)    
        infile= np.loadtxt(inputfile_dir)
        if(not domultipo):
            NO=infile[0:len(infile[:,0])-1,0]
            kp_mock=infile[0:len(infile[:,0])-1,1]  
            Pg0_mock[:,k]=infile[0:len(infile[:,0])-1,2]
        if(domultipo):
            kp_mock       = np.concatenate([infile[0:len(infile[:,0])-1,1],infile[0:len(infile[:,0])-1,1]])
            Pg0_mock[:,k] = np.concatenate([infile[0:len(infile[:,0])-1,2],infile[0:len(infile[:,0])-1,3]])              
    if(PS_type=='den+mom'):
        inputfile_dirden=infile_PS_mocksden+str(i_mock)+'.'+str(j_mock) 
        inputfile_dirmom=infile_PS_mocksmom+str(i_mock)+'.'+str(j_mock) 
        if(not domultipo):             
            infile= np.loadtxt(inputfile_dirden)
            kp_mock=infile[0:len(infile[:,0])-1,1]  
            Pg0_mock[0:NSS,k]=infile[0:len(infile[:,0])-1,2]             
            infile= np.loadtxt(inputfile_dirmom)
            kp_mock=infile[0:len(infile[:,0])-1,1]  
            Pg0_mock[NSS:2*NSS,k]=infile[0:len(infile[:,0])-1,2]
        if(domultipo):
            infileD=np.loadtxt(inputfile_dirden)
            infileM=np.loadtxt(inputfile_dirmom)
            kp_mock=np.concatenate([infileD[0:len(infileD[:,0])-1,1],infileD[0:len(infileD[:,0])-1,1],infileD[0:len(infileD[:,0])-1,1],infileD[0:len(infileD[:,0])-1,1]])
            Pg0_mock[:,k]=np.concatenate([infileD[0:len(infileD[:,0])-1,2],infileD[0:len(infileD[:,0])-1,3],infileM[0:len(infileM[:,0])-1,2],infileM[0:len(infileM[:,0])-1,3]])    
    k=k+1;
# calculate measurement errors:
if(PS_type=='den+mom'):
    Pave=np.array([0.]*(Nmultipo*2*NSS));ePk_obs=np.array([0.]*(Nmultipo*2*NSS));ekPk_obs=np.array([0.]*Nmultipo*NSS)
    for i in range(2**Nmultipo*NSS):
        Pave[i]=np.mean(Pg0_mock[i,:])
        ePk_obs[i]=np.std(Pg0_mock[i,:])
        if(i<Nmultipo*NSS):
            ekPk_obs[i]=np.std(kp_mock[i]*Pg0_mock[i,:])    
else:
    Pave=np.array([0.]*Nmultipo*NSS);ePk_obs=np.array([0.]*Nmultipo*NSS);ekPk_obs=np.array([0.]*Nmultipo*NSS)
    for i in range(Nmultipo*NSS):
        Pave[i]=np.mean(Pg0_mock[i,:])
        ePk_obs[i]=np.std(Pg0_mock[i,:])
        ekPk_obs[i]=np.std(kp_mock[i]*Pg0_mock[i,:])
# set in put PS from mocks, peak vs. mean:
if(PS_measure== 'mocks'):
    k_data =kp_mock
    Pk_data=Pave       
    if(PS_type=='den+mom'):
        if(fit_tech=='Chi2'):
            Pk_data=Pave
        else:    
            Pk_data=np.zeros(2*Nmultipo*NSS)
            for i in range(2*Nmultipo*NSS):
                Gaussian_KDE = stats.gaussian_kde(Pg0_mock[i,:])        
                ss=Pg0_mock[i,Gaussian_KDE.pdf(Pg0_mock[i,:])==max(Gaussian_KDE.pdf(Pg0_mock[i,:]))  ]
                Pk_data[i]=ss[0]
    else:
        if(fit_tech=='Chi2'):
            Pk_data=Pave
        else:    
            Pk_data=np.zeros(Nmultipo*NSS)
            for i in range(Nmultipo*NSS):
                Gaussian_KDE = stats.gaussian_kde(Pg0_mock[i,:])        
                ss=Pg0_mock[i,Gaussian_KDE.pdf(Pg0_mock[i,:])==max(Gaussian_KDE.pdf(Pg0_mock[i,:]))  ]
                Pk_data[i]=ss[0]        











    
    
# 2. calculate the window function matrix:---------------------------------
# the matrix WF_CONV[ki][kj] is used for convert the 
# model PS, Pt[j] to match the measured PS, Pm[i].
# 2.1: Ki is for the output, which corresponds to measured PS:
Ki    = k_data[0:NKs-1]
# 2,2: Kj is for the input, which corresponds to model PS:
ind_Klinear=np.where((k_linear>=min(Ki)) & (k_linear<=max(Ki)))
kjmin=min(k_linear[ind_Klinear])
kjmax=CONV_kmax#2.5#max(k_linear[ind_Klinear])
Kj=np.array([0.]*(nkj+1))
for j in range(nkj+1):
    Kj[j]=kjmin + j*(kjmax-kjmin)/nkj
# 2.3: Window function of random catlog for CF4: WF_rand = [k_rand , W2_rand]
WF_rand =  [k_rand,Pk_rand] 
# 2.4: The WF matrix WFij is to convert the input model PS(kj) 
# to the output PS(ki):
if(WFCon_type=='Ross'):    
    #WFij=WF_CONV(Ki,Kj,WF_rand,Ncosa,epsilon_par) # win[0:39,:]#
    #WFij=np.save('/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/Wij_rossCF4',WFij,allow_pickle=True)
    WFij=np.load('/Users/fei/WSP/Scie/Proj6/Data/Prod/PS/Wij_rossCF4.npy',allow_pickle=True)
if(WFCon_type=='Blake'):
    kjmin,kjmax,nkj,WFij=np.load(input_WFcon ,allow_pickle=True)
    Kj=np.array([0.]*(nkj))
    for j in range(nkj):
        Kj[j]=kjmin + j*(kjmax-kjmin)/nkj
    
plt.figure(3)
plt.pcolor(WFij)
plt.title('WF-convolution matrix')
plt.xlabel('$k_j$ model')
plt.ylabel('$k_i$ data') 
# 2.5: extent the P_linear to Kj size:
ind_Pkinput=np.where((k_linear>=0.0025) & (k_linear<=1.0))
plt.figure(4) 
plt.plot(np.log10(k_linear),np.log10(Pk_linear),color='k')  
plt.plot(np.log10(k_linear[ind_Pkinput]),np.log10(Pk_linear[ind_Pkinput]),color='r') 
plt.title('Input CAMB linear PS')
plt.legend(('CAMB linear', 'input CAMB linear'),loc='lower center') 



#3. calculate the cosmic parameters:---------------------------------------
#f=np.loadtxt('/Users/fei/WSP/Scie/Proj3/Data/Orig/PT_integrals_waves_linear.dat')
#f=np.loadtxt('/Volumes/QINFAT/DataR/Proj3/Data/Orig/PT_integrals_waves_linear.dat')
#f[:,26] -= f[:,38]
#f[:,27] -= 4.0/9.0*f[:,38]
#f[:,28] -= 2.0/3.0*f[:,38]
#for i in range(40):
#    plt.figure(i)
#    plt.plot(f[:,0],f[:,i],color='r')
#    plt.plot(PT[0,:],PT[i,:],color='b',linestyle='--')

kmod         = k_linear[ind_Pkinput]
Pkmod_L      = Pk_linear[ind_Pkinput]

k_obs        = k_data 
Pk_obs       = Pk_data

kmod_conv    = Kj
WF_Kobs_Kmod = WFij

k_mocks      = kp_mock 
Pk_mocks     = Pg0_mock

#PT=Param_Estimateprep( kmod,Pkmod_L,outInteg_dir)
PT=np.loadtxt(outInteg_dir)
PT=PT.T
PT[26,0:] -= PT[38,0:];PT[27,0:] -= 4.0/9.0*PT[38,0:];PT[28,0:] -= 2.0/3.0*PT[38,0:]
# Normalise K_01, K_01^s and K_02^s so that they go to zero as k->0. We have already computed the normalisation.

Growthz = GrowthFactorGR(0.0357, 0.3121, 1.0-0.3121, 0.0, 100.0, -1.0, 0.0, 0.0)/GrowthFactorGR(0.0, 0.3121, 1.0-0.3121, 0.0, 100.0, -1.0, 0.0, 0.0)

# 3.1 damp_type=sep:----------------------------------------------------------- 
print( 'Damp_type=',Damp_type)

if(Damp_type ==   'sep'):
   if(strategy =='Optimize'):
      if(PS_type=='mom'):
          fsigma8,b1sigma8,  b2sigma8, sigma_v1,sigma_v2,sigma_v3,chi2s= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
          print( 'fsigma8 =', fsigma8)
          print( 'b1sigma8=', b1sigma8,'b2sigma8=', b2sigma8 )
          print( 'sigma_v1  =', sigma_v1 ,'sigma_v2  =', sigma_v2,'sigma_v3  =', sigma_v3)
          print( 'CHI2=',chi2s    )    
          param_test  = [b1sigma8, fsigma8, b2sigma8, sigma_v1,sigma_v2,sigma_v3]
          if(domultipo ):var= plt_mom_multi(8,param_test,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs,ePk_obs,WFij,Sig8_fid,PT,PS_type,Nparms,Growthz,Damp_type,domultipo)     
          if(not domultipo):var=plt_mom(8,param_test,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs,Pk_obs,ePk_obs,WF_rand,WFij,Sig8_fid,PT,WFCon_type,PS_type,Nparms,Growthz,Damp_type,domultipo)
      if(PS_type=='den'):
          fsigma8,b1sigma8,  b2sigma8,sigma_v1,sigma_v2,sigma_v3,chi2s= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
          print( 'fsigma8 =', fsigma8)
          print( 'b1sigma8=', b1sigma8,'b2sigma8=', b2sigma8)
          print( 'sigma_v1  =', sigma_v1 ,'sigma_v2  =', sigma_v2,'sigma_v3  =', sigma_v3)
          print( 'CHI2=',chi2s)
          param_test  = [b1sigma8, fsigma8, b2sigma8, sigma_v1,sigma_v2,sigma_v3]
          if(domultipo):var= plt_den_multi(8,param_test,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs,ekPk_obs,WFij,Sig8_fid,PT,PS_type,Nparms,Growthz,Damp_type,domultipo)     
          if(not domultipo):var=plt_den(8,param_test,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs,Pk_obs,ekPk_obs,WF_rand,WFij,Sig8_fid,PT,WFCon_type,PS_type,Nparms,Growthz,Damp_type,domultipo)      
      if(PS_type=='den+mom'):
          if(Nparms==8):
              fsigma8,b1sigma8, b2sigma8,sigma_v1,sigma_v2,sigma_v3,b1vsigma8,b2vsigma8,sigmav_v1,sigmav_v2,sigmav_v3,chi2s= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
              print( 'fsigma8  =', fsigma8)
              print( 'b1sigma8 =', b1sigma8,'b2sigma8  =', b2sigma8)
              print( 'b1sigma8v=',b1vsigma8,'b2sigma8v =', b2vsigma8)
              print( 'sigma_v1  =', sigma_v1 ,'sigma_v2  =', sigma_v2,'sigma_v3  =', sigma_v3)
              print( 'sigmav_v1  =', sigmav_v1 ,'sigmav_v2  =', sigmav_v2,'sigmav_v3  =', sigmav_v3)
              print( 'CHI2=',chi2s)
              param_testm  = [b1vsigma8, fsigma8, b2vsigma8, sigmav_v1,sigmav_v2,sigmav_v3]
              param_testd  = [b1sigma8,  fsigma8,  b2sigma8,  sigma_v1, sigma_v2,sigma_v3]
          if(Nparms==5):
              fsigma8,b1sigma8,  b2sigma8,sigma_v1,sigma_v2,sigma_v3,chi2s= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
              print( 'fsigma8 =', fsigma8)
              print( 'b1sigma8=', b1sigma8,'b2sigma8=', b2sigma8)
              print( 'sigma_v1  =', sigma_v1 ,'sigma_v2  =', sigma_v2,'sigma_v3  =', sigma_v3)
              print( 'CHI2=',chi2s)
              param_testm  = [b1sigma8, fsigma8, b2sigma8, sigma_v1,sigma_v2,sigma_v3]
              param_testd  = param_testm
          PStype='mom'
          if(domultipo ):    var= plt_mom_multi(8,param_testm,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs[2*NSS:],ePk_obs[2*NSS:],WFij,Sig8_fid,PT,PStype,Nparms,Growthz,Damp_type,domultipo)     
          if(not domultipo): var=plt_mom(8,param_testm,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs[NSS:2*NSS],ePk_obs[NSS:2*NSS],WF_rand,WFij,Sig8_fid,PT,WFCon_type,PStype,Nparms,Growthz,Damp_type,domultipo)
          PStype='den'
          if(domultipo):     var= plt_den_multi(9,param_testd,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs[0:(2*NSS)],ekPk_obs,WFij,Sig8_fid,PT,PStype,Nparms,Growthz,Damp_type,domultipo)     
          if(not domultipo): var=plt_den(9,param_testd,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs[0:NSS],ekPk_obs[0:NSS],WF_rand,WFij,Sig8_fid,PT,WFCon_type,PStype,Nparms,Growthz,Damp_type,domultipo)      
   
'''    
 if(strategy =='MCMC'):      
    chain= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo)
    step=np.zeros(len(chain[0:2000,0]))
    for i in range(len(step)):
        step[i]=i
    plt.figure(12)
    plt.plot(step,chain[0:len(step)])
    plt.figure(13)
    plt.hist(chain[:,0],50);
    plt.figure(14)
    plt.hist(chain[:,1],50);
    plt.figure(15)
    plt.hist(chain[:,2],50);
    plt.figure(16)
    plt.hist(chain[:,3],50);
    plt.figure(17)
    plt.hist(chain[:,4],50);
    plt.figure(18)
    plt.hist(chain[:,5],50);
    outfile    = open(output_MCMCchian, 'w')
    for i in range(len(chain[:,0])):   
      if(PS_type=='den+mom'):  
        if(Nparms==8):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n"% (chain[i,1],chain[i,0],chain[i,2],chain[i,3],chain[i,4],chain[i,5],chain[i,6],chain[i,7],chain[i,8],chain[i,9],chain[i,10]))
        if(Nparms==5):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n"% (chain[i,1],chain[i,0],chain[i,2],chain[i,3],chain[i,4],chain[i,5]))
      else:
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n"% (chain[i,1],chain[i,0],chain[i,2],chain[i,3],chain[i,4],chain[i,5]))
    outfile.close()
'''    
# 3.2 damp_type=non:----------------------------------------------------------- 
if(Damp_type =='unif'):
   if(strategy =='Optimize'):
      if(PS_type=='mom'):
          fsigma8,b1sigma8,  b2sigma8, sigma_v,chi2s= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
          print( 'fsigma8 =', fsigma8)
          print( 'b1sigma8=', b1sigma8,'b2sigma8=', b2sigma8 )
          print( 'sigma_v  =', sigma_v)
          print( 'CHI2=',chi2s   )    
          param_test   = [b1sigma8, fsigma8, b2sigma8, sigma_v]   
          if(domultipo ):var= plt_mom_multi(8,param_test,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs,ePk_obs,WFij,Sig8_fid,PT,PS_type,Nparms,Growthz,Damp_type,domultipo)     
          if(not domultipo):var=plt_mom(8,param_test,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs,Pk_obs,ePk_obs,WF_rand,WFij,Sig8_fid,PT,WFCon_type,PS_type,Nparms,Growthz,Damp_type,domultipo)
      if(PS_type=='den'):
          fsigma8,b1sigma8,  b2sigma8,sigma_v,chi2s= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
          print( 'fsigma8 =', fsigma8)
          print( 'b1sigma8=', b1sigma8,'b2sigma8=', b2sigma8)
          print( 'sigma_v  =', sigma_v)
          print( 'CHI2=',chi2s)
          param_test  = [b1sigma8, fsigma8, b2sigma8, sigma_v]
          if(domultipo):var= plt_den_multi(8,param_test,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs,ekPk_obs,WFij,Sig8_fid,PT,PS_type,Nparms,Growthz,Damp_type,domultipo)     
          if(not domultipo):var=plt_den(8,param_test,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs,Pk_obs,ekPk_obs,WF_rand,WFij,Sig8_fid,PT,WFCon_type,PS_type,Nparms,Growthz,Damp_type,domultipo)      
      if(PS_type=='den+mom'):
          if(Nparms==8):
              fsigma8,b1sigma8, b2sigma8,sigma_v,b1vsigma8,b2vsigma8,sigmav_v,chi2s= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
              print( 'fsigma8  =', fsigma8)
              print( 'b1sigma8 =', b1sigma8,'b2sigma8  =', b2sigma8)
              print( 'b1sigma8v=',b1vsigma8,'b2sigma8v =', b2vsigma8)
              print( 'sigma_v  =', sigma_v, 'sigmav_v  =', sigmav_v)
              print( 'CHI2=',chi2s)
              param_testm  = [b1vsigma8, fsigma8, b2vsigma8, sigmav_v]
              param_testd  = [b1sigma8,  fsigma8,  b2sigma8,  sigma_v]
          if(Nparms==5):
              fsigma8,b1sigma8,  b2sigma8,sigma_v,chi2s= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
              print( 'fsigma8 =', fsigma8)
              print( 'b1sigma8=', b1sigma8,'b2sigma8=', b2sigma8)
              print( 'sigma_v1  =', sigma_v)
              print( 'CHI2=',chi2s)
              param_testm  = [b1sigma8, fsigma8, b2sigma8, sigma_v]
              param_testd  = param_testm
          PStype='mom'
          if(domultipo ):    var= plt_mom_multi(8,param_testm,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs[2*NSS:],ePk_obs[2*NSS:],WFij,Sig8_fid,PT,PStype,Nparms,Growthz,Damp_type,domultipo)     
          if(not domultipo): var=plt_mom(8,param_testm,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs[NSS:2*NSS],ePk_obs[NSS:2*NSS],WF_rand,WFij,Sig8_fid,PT,WFCon_type,PStype,Nparms,Growthz,Damp_type,domultipo)
          PStype='den'
          if(domultipo):     var= plt_den_multi(9,param_testd,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs[0:(2*NSS)],ekPk_obs,WFij,Sig8_fid,PT,PStype,Nparms,Growthz,Damp_type,domultipo)     
          if(not domultipo): var=plt_den(9,param_testd,fit_minK,fit_maxK,NKs,kmod,kmod_conv,k_obs[0:(NKs-1)],Pk_obs[0:NSS],ekPk_obs[0:NSS],WF_rand,WFij,Sig8_fid,PT,WFCon_type,PStype,Nparms,Growthz,Damp_type,domultipo)      

    
    
    
    

    
   if(strategy =='MCMC'): 
    chain= Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,domultipo,Nmultipo)
    step=np.zeros(len(chain[0:100,0]))
    for i in range(len(step)):
        step[i]=i
    plt.figure(12)
    plt.plot(step,chain[0:len(step)])
    plt.figure(13)
    plt.hist(chain[:,0],50);
    plt.figure(14)
    plt.hist(chain[:,1],50);
    plt.figure(15)
    plt.hist(chain[:,2],50);
    plt.figure(16)
    plt.hist(chain[:,3],50);
    outfile    = open(output_MCMCchian, 'w')
    for i in range(len(chain[:,0])):   
      if(PS_type=='den+mom'):  
        if(Nparms==8):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n"% (chain[i,1],chain[i,0],chain[i,2],chain[i,3],chain[i,4],chain[i,5],chain[i,6]))
        if(Nparms==5):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf\n"% (chain[i,1],chain[i,0],chain[i,2],chain[i,3]))
      else:
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf\n"% (chain[i,1],chain[i,0],chain[i,2],chain[i,3]))
    outfile.close()    
    
    
plt.show()  
##########  THE END  ##################################################
