import math
import numpy as np
import matplotlib.pyplot as plt
from CosmoFunc import *
from WINfunCon import *
from FQin import *






'''





OmegaM         = 0.3121
OmegaA         = 1.0-OmegaM
Hub            = 100.

Input_dir_Rand = '/Users/fei/WSP/Scie/Proj7/Data/Prod/PS/mocks/6dFGSvRand.txt'
Output_dir     = '/Users/fei/WSP/Scie/Proj7/Data/Prod/PS/6dFGSv_convmat'
 
nx,ny,nz    = 128,128,128
lx,ly,lz    = 768.0, 768.0, 768.0
pk0         = 5.0e9

kmin ,kmax , nkbin = 0.0,0.39,39
kminc,kmaxc,nkbinc = 0.0,0.4,80
#  -------------------------------------------------------------
print('convmat mom-PS')
infile        = np.loadtxt(Input_dir_Rand)
longitude_rand= infile[:,0]
latitude_rand = infile[:,1]
Vcmb_rand     = infile[:,2]
ePvR          = infile[:,3]
rand_nbar     = infile[:,5]#infile[:,4]

rand_x,rand_y,rand_z = Sky2Cat(longitude_rand,latitude_rand,Vcmb_rand/LightSpeed,OmegaM,OmegaA,Hub,nbin=10000,redmax=1.3)
N_randratio = len(rand_x)/8885.0

wingridgal,weigridgal = Prep_winFUN(N_randratio,rand_nbar,ePvR,pk0,rand_x,rand_y,rand_z,nx,ny,nz,lx,ly,lz,'mom')
convmat  = getpoleconvmat(kmin,kmax,nkbin,kmaxc,nkbinc,nx,ny,nz,lx,ly,lz,weigridgal,wingridgal )

np.save(Output_dir,[kminc,kmaxc,nkbinc,convmat],allow_pickle=True)

plt.figure(1)
plt.pcolor(convmat)
plt.title('mom WF-convolution matrix')
plt.xlabel('$k_j$ model')
plt.ylabel('$k_i$ data') 



#mat=np.loadtxt('/Users/fei/Downloads/6dfgsmock_velocity_random_norsd.convmat_FKP5e9')





'''








#------------------------------------------------------------------------------

OmegaM         = 0.3121
OmegaA         = 1.0-OmegaM
Hub            = 100.

Input_dir_Rand = '/Users/fei/WSP/Scie/Proj7/Data/Prod/PS/mocks/6dFGSRand.txt'
Output_dir     = '/Users/fei/WSP/Scie/Proj7/Data/Prod/PS/6dFGS_convmat'
 
nx,ny,nz    = 128, 128, 128
lx,ly,lz    = 768.0, 768.0, 768.0
pk0         = 1600.0

kmin ,kmax , nkbin = 0.0,0.4,40 # 0.0,0.39,39
kminc,kmaxc,nkbinc = 0.0,0.4,80
# -------------------------------------------------------------
print('convmat den-PS')
infile=np.loadtxt(Input_dir_Rand)
longitude_rand=infile[:,0]
latitude_rand=infile[:,1]
Vcmb_rand=infile[:,2]
rand_nbar=infile[:,4]#infile[:,3]

rand_x,rand_y,rand_z  = Sky2Cat(longitude_rand,latitude_rand,Vcmb_rand/LightSpeed,OmegaM , OmegaA ,Hub,nbin=10000,redmax=1.3)
N_randratio = 8.4#100

wingridgal,weigridgal = Prep_winFUN(N_randratio,rand_nbar,np.nan,pk0,rand_x,rand_y,rand_z,nx,ny,nz,lx,ly,lz,'den')
convmat  = getpoleconvmat(kmin,kmax,nkbin,kmaxc,nkbinc,nx,ny,nz,lx,ly,lz,weigridgal,wingridgal )

np.save(Output_dir,[kminc,kmaxc,nkbinc,convmat],allow_pickle=True)

plt.figure(1)
plt.pcolor(convmat)
plt.title('den WF-convolution matrix')
plt.xlabel('$k_j$ model')
plt.ylabel('$k_i$ data') 




#mat=np.loadtxt('/Users/fei/Downloads/6dfgsmock_redshift_random_norsd.convmat_FKP10000')

#mat=np.loadtxt('/Users/fei/Downloads/6dfgsmock_redshift_random_norsd.convmat_FKP10000');plt.scatter(convmat.flatten(),mat.flatten());plt.plot(mat.flatten(),mat.flatten(),color='k')

plt.show()
# The end #####################################################################    
