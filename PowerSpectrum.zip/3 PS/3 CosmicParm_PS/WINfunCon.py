import sys
import numpy as np
from scipy.special import sph_harm
 












def discret_rand(xpos,ypos,zpos,nx,ny,nz,lx,ly,lz):
    datgrid,edges = np.histogramdd(np.vstack([xpos,ypos,zpos]).transpose(),bins=(nx,ny,nz),range=((-lx/2.,lx/2.),(-ly/2.,ly/2.),(-lz/2.,lz/2.))   )     
    return datgrid

def discret_randV(xpos,ypos,zpos,nx,ny,nz,lx,ly,lz,wei):
    datgrid,edges = np.histogramdd(np.vstack([xpos,ypos,zpos]).transpose(),bins=(nx,ny,nz),range=((-lx/2.,lx/2.),(-ly/2.,ly/2.),(-lz/2.,lz/2.)),weights=wei)
    return datgrid

def Prep_winFUN(N_randratio,rand_nbar,pvR,pk0,rand_x,rand_y,rand_z,nx,ny,nz,lx,ly,lz,types ):
    nrand=N_randratio
    vol = lx*ly*lz
    rand_w = 1.0/(1.0 + rand_nbar*pk0)
    randgrid = discret_rand(rand_x,rand_y,rand_z,nx,ny,nz,lx,ly,lz )
    wingrid = randgrid
    if(types=='den'):    
        weigrid = 1./(1.0+(randgrid/nrand*float(nx*ny*nz)/vol)*pk0)
    if(types=='mom'):
        pverrgrid =discret_randV(rand_x,rand_y,rand_z,nx,ny,nz,lx,ly,lz,pvR)
        pverrgrid[randgrid > 0] /= randgrid[randgrid > 0]
        pverrgrid += 300.0**2
        weigrid = 1./(pverrgrid+(randgrid/nrand*float(nx*ny*nz)/vol)*pk0)
    return wingrid,weigrid

def getkspec(nx,ny,nz,lx,ly,lz):
    kx = 2.*np.pi*np.fft.fftfreq(nx,d=lx/nx)
    ky = 2.*np.pi*np.fft.fftfreq(ny,d=ly/ny)
    kz = 2.*np.pi*np.fft.fftfreq(nz,d=lz/nz)
    indep = np.full((nx,ny,nz),True,dtype=bool)
    indep[0,0,0] = False
    kspec = np.sqrt(kx[:,np.newaxis,np.newaxis]**2 + ky[np.newaxis,:,np.newaxis]**2 + kz[np.newaxis,np.newaxis,:]**2)
    kspec[0,0,0] = 1.
    muspec = np.absolute(kx[:,np.newaxis,np.newaxis])/kspec
    kspec[0,0,0] = 0.
    return kspec,muspec,indep

def binpk(pkspec,nx,ny,nz,lx,ly,lz,kmin,kmax,nkbin):
    #print 'Binning in angle-averaged bins...'
    kspec,muspec,indep = getkspec(nx,ny,nz,lx,ly,lz)
    pkspec = pkspec[indep == True]
    kspec = kspec[indep == True]
    ikbin = np.digitize(kspec,np.linspace(kmin,kmax,nkbin+1))
    nmodes,pk = np.zeros(nkbin,dtype=int),np.full(nkbin,-1.)
    for ik in range(nkbin):
      nmodes[ik] = int(np.sum(np.array([ikbin == ik+1])))
      if (nmodes[ik] > 0):
        pk[ik] = np.mean(pkspec[ikbin == ik+1])
    return pk,nmodes












#==============================================================================
#                        use conv-matrix to do conv
#==============================================================================
# 1: get convolution matrix:
def getpoleconvmat(kmin,kmax,nkbin,kmaxc,nkbinc,nx,ny,nz,lx,ly,lz,weigrid,wingrid):
# Initializations
  nlconv = 3 # Number of multipoles to include in convolution
  dk = (kmax-kmin)/nkbin
  dkc = (kmaxc-kmin)/nkbinc
  k1 = np.linspace(kmin,kmaxc-dkc,nkbinc)
  k2 = np.linspace(kmin+dkc,kmaxc,nkbinc)
  convmat = np.zeros((3*nkbin,3*nkbinc))
# Convolve series of unit vectors
  iconv = -1
  for imult in range(nlconv):
    for ik in range(nkbinc):
      iconv += 1
      print( 'Obtaining convolution for bin',iconv+1,'of',nlconv*nkbinc,'...')
      pk0,pk2,pk4 = 0.,0.,0.
      if (imult == 0):
        pk0 = 1.
        l = 0
      elif (imult == 1):
        pk2 = 1.
        l = 2
      elif (imult == 2):
        pk4 = 1.
        l = 4
      kmin1,kmax1 = k1[ik],k2[ik]
      pk0con,pk2con,pk4con = getpoleconvharmmat(nx,ny,nz,lx,ly,lz,kmin,kmax,nkbin,weigrid,wingrid,kmin1,kmax1,pk0,pk2,pk4)
      convmat[:,iconv] = np.concatenate((pk0con,pk2con,pk4con))
  return convmat
# 2: Convolve power spectrum multipoles using spherical harmonics.-------------
# Convolve unit power spectrum multipoles using spherical harmonics
# This is similar to getpoleconv, modified such that the power spectrum
# model is assumed to be zero, except that the power spectrum multipoles
# have constant values (pk0,pk2,pk4) within a bin kmin1 < k < kmax1
def getpoleconvharmmat(nx,ny,nz,lx,ly,lz,kmin,kmax,nkbin,weigrid,wingrid,kmin1,kmax1,pk0,pk2,pk4):
  nl = 3    # Number of multipoles to compute
  nlmod = 3 # Number of multipoles in model
# Initializations
  wingrid=wingrid/np.sum(wingrid)
  dx,dy,dz,nc = lx/nx,ly/ny,lz/nz,float(nx*ny*nz)
  x = dx*np.arange(nx) - lx/2. + 0.5*dx
  y = dy*np.arange(ny) - ly/2. + 0.5*dy
  z = dz*np.arange(nz) - lz/2. + 0.5*dz
  kx = 2.*np.pi*np.fft.fftfreq(nx,d=dx)
  ky = 2.*np.pi*np.fft.fftfreq(ny,d=dy)
  kz = 2.*np.pi*np.fft.fftfreq(nz,d=dz)
  rgrid = np.sqrt(x[:,np.newaxis,np.newaxis]**2 + y[np.newaxis,:,np.newaxis]**2 + z[np.newaxis,np.newaxis,:]**2)
  kgrid = np.sqrt(kx[:,np.newaxis,np.newaxis]**2 + ky[np.newaxis,:,np.newaxis]**2 + kz[np.newaxis,np.newaxis,:]**2)
  sumw = np.sum(wingrid)
  sumwsq = nc*np.sum(((wingrid/sumw)*weigrid)**2)
# Unconvolved power spectrum multipoles
  dk = (kmax-kmin)/nkbin
  kbin = np.linspace(kmin+0.5*dk,kmax-0.5*dk,nkbin)
  mask = (kgrid >= kmin1) & (kgrid < kmax1)
# Obtain spherical polar angles over the grid
  xthetagrid = np.arctan2(z[np.newaxis,np.newaxis,:],y[np.newaxis,:,np.newaxis])
  xphigrid = np.where(rgrid>0.,np.arccos(x[:,np.newaxis,np.newaxis]/rgrid),0.)
  kthetagrid = np.arctan2(kz[np.newaxis,np.newaxis,:],ky[np.newaxis,:,np.newaxis])
  kphigrid = np.where(kgrid>0.,np.arccos(kx[:,np.newaxis,np.newaxis]/kgrid),0.)
# Fourier transform window function  
  winspec = np.fft.fftn(weigrid*(wingrid/sumw))
  
# Compute convolutions
  pk0con,pk2con,pk4con = np.zeros(nkbin),np.zeros(nkbin),np.zeros(nkbin)
  uselp = np.full(nlmod,True,dtype=bool)
  if (pk0 == 0.):
    uselp[0] = False
  if (pk2 == 0.):
    uselp[1] = False
  if (pk4 == 0.):
    uselp[2] = False  
  for il in range(nl):
    l = 2*il
    pkcongrid = np.zeros((nx,ny,nz))
    for m in range(-l,l+1):
      xylmgrid = sph_harm(m,l,xthetagrid,xphigrid)
      kylmgrid = sph_harm(m,l,kthetagrid,kphigrid)
      for ilp in range(nlmod):
        if (uselp[ilp]):          
          lp = 2*ilp
          norm = ((4.*np.pi)**2)/(sumwsq*float(2*lp+1))
          
          plpgrid = np.zeros((nx,ny,nz))
          if (ilp == 0):
            plpgrid[mask] = pk0
          elif (ilp == 1):
            plpgrid[mask] = pk2
          elif (ilp == 2):
            plpgrid[mask] = pk4
          for mp in range(-lp,lp+1):
            xylmpgrid = sph_harm(mp,lp,xthetagrid,xphigrid)
            kylmpgrid = sph_harm(mp,lp,kthetagrid,kphigrid)
            pkmodspec = np.fft.fftn(plpgrid*np.conj(kylmpgrid))
            slmlmpgrid = np.fft.fftn(weigrid*(wingrid/sumw)*xylmgrid*np.conj(xylmpgrid))
            tempspec = np.fft.fftn(winspec*np.conj(slmlmpgrid))
            pkcongrid += norm*np.real(kylmgrid*np.fft.ifftn(pkmodspec*tempspec))
# Average over k modes
    pkcon,nmodes = binpk(pkcongrid,nx,ny,nz,lx,ly,lz,kmin,kmax,nkbin)
    if (il == 0):
      pk0con = pkcon
    elif (il == 1):
      pk2con = pkcon
    elif (il == 2):
      pk4con = pkcon
  return pk0con,pk2con,pk4con
# 3: Apply the convolution matrix to a model-----------------------------------
def Pk_CONV_new(convmat,pkmod,domultipo):
    if(not domultipo):
        nbin = convmat.shape[0] ; nbin2 = convmat.shape[1]  
        pkunconvlst = pkmod
        nkbin1 = nbin//3
        nkbin2 = nbin2//3    
        pkconvlst = np.dot(convmat[:,:nkbin2],pkunconvlst)
        pk0conv = pkconvlst[:nkbin1]
        return pk0conv
    if(domultipo):
        nbin = convmat.shape[0]
        nkbin=nbin//3
        pk4unconv=np.zeros(len(pkmod)//2)      
        pkunconvlst = np.concatenate((pkmod,pk4unconv))#np.concatenate((pk0unconv,pk2unconv,pk4unconv))
        nkbin1 = nbin//3
        pkconvlst = np.dot(convmat,pkunconvlst)
        pk0conv,pk2conv,pk4conv = pkconvlst[:nkbin],pkconvlst[nkbin1:nkbin1+nkbin],pkconvlst[2*nkbin1:2*nkbin1+nkbin]
        return np.concatenate([pk0conv,pk2conv] ) #,pk4conv
     


        
     