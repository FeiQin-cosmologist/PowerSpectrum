import math
import numpy as np
import scipy as sp
from scipy import interpolate
from ParamEstimateCH import *
import matplotlib.pyplot as plt

def plt_mom_multi(i_plt,param_testi,fit_minK,fit_maxK,NKs,kmodi,kmodi_conv,k_obsi,Pk_obsii,ePk_obsii,WFijo,Sig8_fid,PT,PS_typei,Nparms,Growthz,Damp_type,domultipo):
    
    Pkj_tests    = Pk_MOD(param_testi,Sig8_fid,PT,PS_typei,Nparms,Growthz,Damp_type,domultipo)
    P_spline0    = sp.interpolate.splrep(kmodi,Pkj_tests[0:len(kmodi)],s=0) # kmodi=PT[0,:] Pkmodi_L=PT[1,:]
    Pkj_test0    = sp.interpolate.splev(kmodi_conv, P_spline0)
    P_spline2    = sp.interpolate.splrep(kmodi,Pkj_tests[len(kmodi):],s=0) # kmodi=PT[0,:] Pkmodi_L=PT[1,:]
    Pkj_test2    = sp.interpolate.splev(kmodi_conv, P_spline2)
    Pkj_test     = np.concatenate([Pkj_test0,Pkj_test2] )
    Pk_testconv  = Pk_CONV_new(WFijo,Pkj_test,domultipo)
    
    plt.figure(i_plt,figsize=(8,8))
    ax=plt.subplot(211)
    ax.set_yscale("log", nonposy='clip')
    plt.plot(kmodi      , Pkj_tests[0:len(kmodi)]   ,color='r' ,label='unconvoled model'  )    
    plt.plot(k_obsi , Pk_testconv[0:(NKs-1)],color='k', label='convoled model')
    plt.plot(k_obsi, Pk_obsii[0:(NKs-1)],color='k',linestyle='')
    plt.errorbar(k_obsi, Pk_obsii[0:(NKs-1)],ePk_obsii[0:(NKs-1)],linestyle='',color='k',marker="s")
    plt.ylim(10**6,10**13)
    plt.xlim(fit_minK,fit_maxK)
    plt.xlabel('k  [ $h Mpc^{-1}$ ]', fontsize=14)
    plt.ylabel('$P_{0}(k)$  [ $h^{-3} Mpc^3 km^2~s^{-2}$ ]', fontsize=14)
    plt.legend( loc='upper right')
    plt.grid(True)
    plt.title('momentum power spectrum')

    ax=plt.subplot(212)
    ax.set_yscale("log", nonposy='clip')
    plt.plot(kmodi      , Pkj_tests[len(kmodi):]   ,color='r' ,label='unconvoled model'  )    
    plt.plot(k_obsi, Pk_testconv[ (NKs-1):  ],color='k', label='convoled model')
    plt.plot(k_obsi, Pk_obsii[(NKs-1):],color='k',linestyle='')
    plt.errorbar(k_obsi, Pk_obsii[(NKs-1):],ePk_obsii[(NKs-1):],linestyle='',color='k',marker="s")
    plt.ylim(10**6,10**13)
    plt.xlim(fit_minK,fit_maxK)
    plt.xlabel('k  [ $h Mpc^{-1}$ ]', fontsize=14)
    plt.ylabel('$P_{2}(k)$  [ $h^{-3} Mpc^3 km^2~s^{-2}$ ]', fontsize=14)
    plt.legend( loc='upper right')
    plt.grid(True)
    #plt.savefig("/Volumes/QINFAT/DataR/Proj6/Data/Prod/6dF mom.png") 
    return i_plt


def plt_den_multi(i_plt,param_testi,fit_minK,fit_maxK,NKs,kmodi,kmodi_conv,k_obsi,Pk_obsii,ekPk_obsii,WFijo,Sig8_fid,PT,PS_typei,Nparms,Growthz,Damp_type,domultipo):
     
    Pkj_tests    = Pk_MOD(param_testi,Sig8_fid,PT,PS_typei,Nparms,Growthz,Damp_type,domultipo)
    P_spline0    = sp.interpolate.splrep(kmodi,Pkj_tests[0:len(kmodi)],s=0) # kmodi=PT[0,:] Pkmodi_L=PT[1,:]
    Pkj_test0    = sp.interpolate.splev(kmodi_conv, P_spline0)
    P_spline2    = sp.interpolate.splrep(kmodi,Pkj_tests[len(kmodi):],s=0) # kmodi=PT[0,:] Pkmodi_L=PT[1,:]
    Pkj_test2    = sp.interpolate.splev(kmodi_conv, P_spline2)
    Pkj_test     = np.concatenate([Pkj_test0,Pkj_test2] )
    Pk_testconv  = Pk_CONV_new(WFijo,Pkj_test,domultipo)
    
    plt.figure(i_plt,figsize=(8,8))
    ax=plt.subplot(211)
    plt.plot(kmodi      , kmodi*Pkj_tests[0:len(kmodi)]   ,color='r' ,label='unconvoled model'  )  
    plt.plot(k_obsi, k_obsi*Pk_testconv[0:(NKs-1)],color='k', label='convoled model')
    plt.plot(k_obsi, k_obsi*Pk_obsii[0:(NKs-1)],color='k',linestyle='')
    plt.errorbar(k_obsi, k_obsi*Pk_obsii[0:(NKs-1)],ekPk_obsii[0:(NKs-1)],linestyle='',color='k',marker="s")
    plt.ylim(-100,2000)
    plt.xlim(fit_minK,fit_maxK)
    plt.xlabel('k  [ $h Mpc^{-1}$ ]', fontsize=14)
    plt.ylabel('$kP_{0}(k)$  [ $h^{-3} Mpc^3 km^2~s^{-2}$ ]', fontsize=14)
    plt.legend( loc='upper right')
    plt.grid(True)
    plt.title('density power spectrum')

    ax=plt.subplot(212)
    plt.plot(kmodi      , Pkj_tests[len(kmodi):]   ,color='r' ,label='unconvoled model'  )    
    plt.plot(k_obsi, k_obsi*Pk_testconv[(NKs-1): ],color='k', label='convoled model')
    plt.plot(k_obsi, k_obsi*Pk_obsii[(NKs-1):],color='k',linestyle='')
    plt.errorbar(k_obsi, k_obsi*Pk_obsii[(NKs-1):],ekPk_obsii[(NKs-1):],linestyle='',color='k',marker="s")
    plt.ylim(-500,850)
    plt.xlim(fit_minK,fit_maxK)
    plt.xlabel('k  [ $h Mpc^{-1}$ ]', fontsize=14)
    plt.ylabel('$kP_{2}(k)$  [ $h^{-3} Mpc^3 km^2~s^{-2}$ ]', fontsize=14)
    plt.legend( loc='upper right')
    plt.grid(True)
    #plt.savefig("/Volumes/QINFAT/DataR/Proj6/Data/Prod/6dF den.png") 
    return i_plt

 

def plt_mom(i_plt,param_testi,fit_minK,fit_maxK,NKs,kmodi,kmodi_conv,k_obsi,Pk_obsii,ePk_obsii,WF_rand,WFijo,Sig8_fid,PT,WFCon_type,PS_typei,Nparms,Growthz,Damp_type,domultipo):
    
    Pkj_tests   = Pk_MOD(param_testi,Sig8_fid,PT,PS_typei,Nparms,Growthz,Damp_type,domultipo)
    P_spline    = sp.interpolate.splrep(kmodi,Pkj_tests,s=0) # kmodi=PT[0,:] Pkmodi_L=PT[1,:]
    Pkj_test    = sp.interpolate.splev(kmodi_conv, P_spline)

    if(WFCon_type=='Ross'):Pk_testconv = Pk_CONV(k_obsi,WFijo,Pkj_test,WF_rand[0],WF_rand[1])
    if(WFCon_type=='Blake'):Pk_testconv = Pk_CONV_new(WFijo,Pkj_test,domultipo)
    
    plt.figure(i_plt)
    ax=plt.subplot(111)
    ax.set_yscale("log", nonposy='clip')
    plt.plot(kmodi      , Pkj_tests   ,color='r' ,label='unconvoled model'  )    
    plt.plot(k_obsi, Pk_testconv[0:(NKs-1)],color='k', label='convoled model')
    plt.plot(k_obsi, Pk_obsii,color='k',linestyle='')
    plt.errorbar(k_obsi, Pk_obsii,ePk_obsii,linestyle='',color='k',marker="s")
    plt.ylim(10**6,10**13)
    plt.xlim(fit_minK,fit_maxK)
    plt.xlabel('k  [ $h Mpc^{-1}$ ]', fontsize=14)
    plt.ylabel('$P_{0}(k)$  [ $h^{-3} Mpc^3 km^2~s^{-2}$ ]', fontsize=14)
    plt.legend( loc='upper right')
    plt.grid(True)
    plt.title('momentum power spectrum')
    #plt.savefig("/Volumes/QINFAT/DataR/Proj6/Data/Prod/6dF mom.png") 
    return i_plt


def plt_den(i_plt,param_testi,fit_minK,fit_maxK,NKs,kmodi,kmodi_conv,k_obsi,Pk_obsii,ekPk_obsii,WF_rand,WFijo,Sig8_fid,PT,WFCon_type,PS_typei,Nparms,Growthz,Damp_type,domultipo):
    
    Pkj_tests    = Pk_MOD(param_testi,Sig8_fid,PT,PS_typei,Nparms,Growthz,Damp_type,domultipo)
    P_spline     = sp.interpolate.splrep(kmodi,Pkj_tests,s=0) # kmodi=PT[0,:] Pkmodi_L=PT[1,:]
    Pkj_test     = sp.interpolate.splev(kmodi_conv, P_spline)
    
    if(WFCon_type=='Ross'):Pk_testconv = Pk_CONV(k_obsi,WFijo,Pkj_test,WF_rand[0],WF_rand[1])
    if(WFCon_type=='Blake'):Pk_testconv = Pk_CONV_new(WFijo,Pkj_test,domultipo)    
    
    plt.figure(i_plt)
    ax=plt.subplot(111)
    plt.plot(kmodi      , kmodi*Pkj_tests[0:len(kmodi)]   ,color='r' ,label='unconvoled model' )    
    plt.plot(k_obsi[0:(NKs-1)], k_obsi[0:(NKs-1)]*Pk_testconv[0:(NKs-1)],color='k' , label='convoled model')
    plt.plot(k_obsi[0:(NKs-1)], k_obsi[0:(NKs-1)]*Pk_obsii[0:(NKs-1)],color='k',linestyle='')
    plt.errorbar(k_obsi[0:(NKs-1)], k_obsi[0:(NKs-1)]*Pk_obsii[0:(NKs-1)],ekPk_obsii[0:(NKs-1)],linestyle='',color='k',marker="s")
    plt.ylim(-100,1700)
    plt.xlim(fit_minK,fit_maxK)
    plt.xlabel('k  [ $h Mpc^{-1}$ ]', fontsize=14)
    plt.ylabel('$kP_{0}(k)$  [ $h^{-3} Mpc^3 km^2~s^{-2}$ ]', fontsize=14)
    plt.legend( loc='upper right')
    plt.grid(True)
    plt.title('density power spectrum')

    #plt.savefig("/Volumes/QINFAT/DataR/Proj6/Data/Prod/6dF den.png") 
    return i_plt



   



   

