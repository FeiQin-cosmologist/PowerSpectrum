#==========================================================================
#                                  CODE
#--------------------------------------------------------------------------
# 1. INITIAL SETTING:
import math
import numpy as np
import scipy as sp
from scipy import interpolate
import emcee
from itertools import chain
from scipy.linalg import lapack
import matplotlib.pyplot as plt
from sklearn.decomposition import FastICA
from scipy import stats
import camb
from camb import model, initialpower
from WFconv import *
from WINfunCon import *
# https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.FastICA.html#sklearn.decomposition.FastICA
# https://ncss-wpengine.netdna-ssl.com/wp-content/themes/ncss/pdf/Procedures/NCSS/Box-Cox_Transformation.pdf
# https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.boxcox_llf.html
def PS_extender(k,Pk,k_start,k_end):
    #k_store=k
    XX=k[k_start:k_end]
    YY=Pk[k_start:k_end]
    plt.plot(np.log10(k),np.log10(Pk))
    plt.scatter(np.log10(XX),np.log10(YY),color='r',s=10)
    x=np.log10(XX)
    y=np.log10(YY)
    KK,BB=np.polyfit(x,y,1)
    plt.plot(x,KK*x+BB)
    dks=0.001
    krs=np.zeros(int((10.0-max(k))/dks))
    for i in range(int((10.0-max(k))/dks)):
        krs[i]=max(k)+(i+1)*dks
    KRAND=k
    PKRAND=Pk
    k=np.zeros(len(KRAND)+int((10.0-max(k))/dks))
    Pk=np.zeros(len(k))
    k[0:len(KRAND)]=KRAND
    k[len(KRAND):len(KRAND)+int((10.0-max(k))/dks)]=krs
    Pk[0:len(KRAND)]=PKRAND
    Pk[len(KRAND):len(k)]=10.0**(KK*np.log10(krs)+BB)
    plt.plot(np.log10(k),np.log10(Pk))
    return k,Pk


# 2. calculate integrations:-----------------------------------------------    
def Fmn(m,n,r,x,y):
    if(m==0) and (n==0):
        FMN=(7.0*x + 3.0*r - 10.0*r*x*x)**2/(14.0*14.0*r*r*y*y*y*y);
    if(m==0) and (n==1):
        FMN= (7.0*x + 3.0*r - 10.0*r*x*x)*(7.0*x - r - 6.0*r*x*x)/(14.0*14.0*r*r*y*y*y*y);
    if(m==0) and (n==2):
        FMN= (x*x - 1.0)*(7.0*x + 3.0*r - 10.0*r*x*x)/(14.0*r*y*y*y*y);
    if(m==0) and (n==3):
        FMN= (1.0 - x*x)*(3.0*r*x - 1.0)/(r*r*y*y);       
    if(m==1) and (n==0):
        FMN= x*(7.0*x + 3.0*r - 10.0*r*x*x)/(14.0*r*r*y*y);
    if(m==1) and (n==1):
        FMN= (7.0*x - r - 6.0*r*x*x)**2/(14.0*14.0*r*r*y*y*y*y);
    if(m==1) and (n==2):
        FMN= (x*x - 1.0)*(7.0*x - r - 6.0*r*x*x)/(14.0*r*y*y*y*y);
    if(m==1) and (n==3):
        FMN=( 4.0*r*x + 3.0*x*x - 6.0*r*x*x*x - 1.0)/(2.0*r*r*y*y);             
    if(m==2) and (n==0):
        FMN= (2.0*x + r - 3.0*r*x*x)*(7.0*x + 3.0*r - 10.0*r*x*x)/(14.0*r*r*y*y*y*y);
    if(m==2) and (n==1):
        FMN= (2.0*x + r - 3.0*r*x*x)*(7.0*x - r - 6.0*r*x*x)/(14.0*r*r*y*y*y*y);
    if(m==2) and (n==2):
        FMN= x*(7.0*x - r - 6.0*r*x*x)/(14.0*r*r*y*y);
    if(m==2) and (n==3):
        FMN= 3.0*(1.0-x*x)*(1.0-x*x)/(y*y*y*y); 
    if(m==3) and (n==0):
        FMN= (1.0 - 3.0*x*x - 3.0*r*x + 5.0*r*x*x*x)/(r*r*y*y);
    if(m==3) and (n==1):
        FMN=  (1.0 - 2*r*x)*(1.0 - x*x)/(2.0*r*r*y*y);
    if(m==3) and (n==2):
        FMN=  (1.0 - x*x)*(2.0 - 12.0*r*x - 3.0*r*r + 15.0*r*r*x*x)/(r*r*y*y*y*y);
    if(m==3) and (n==3):
        FMN=  (-4.0 + 12.0*x*x + 24.0*r*x - 40.0*r*x*x*x + 3.0*r*r - 30.0*r*r*x*x + 35.0*r*r*x*x*x*x)/(r*r*y*y*y*y);        
    return FMN

def Imn_inner_integ(x,m,n,k,r,Pl_spline):
    y    = np.sqrt(1.0+r*r-2.0*r*x)#x=cos theta
    Plkq = sp.interpolate.splev(np.log10(k*y), Pl_spline, der=0)
    return Fmn(m,n,r,x,y)*10.0**(Plkq)

def Imn_outer_integ(r,m,n,k,Pl_spline):
    integ,errin= sp.integrate.quad(Imn_inner_integ,-1.0,1.0,epsabs=0.0,epsrel=1.0e-4,args=(m,n,k,r,Pl_spline))
    Pl   = sp.interpolate.splev(np.log10(k*r),Pl_spline, der=0)
    return r*r*integ*10.0**(Pl)

def I_mn(kmod,Pl_spline,ks):
    Imn=np.zeros((len(ks),4,4))
    for i in range(len(ks)):
        I00,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(0,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,0,0]= I00*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I01,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(0,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,0,1]= I01*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I02,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(0,2,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,0,2]= I02*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I03,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(0,3,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,0,3]= I03*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)

        I10,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(1,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,1,0]= I10*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I11,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(1,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,1,1]= I11*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I12,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(1,2,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,1,2]= I12*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I13,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(1,3,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,1,3]= I13*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)

        I20,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(2,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,2,0]= I20*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I21,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(2,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,2,1]= I21*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I22,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(2,2,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3)
        Imn[i,2,2]= I22*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I23,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(2,3,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,2,3]= I23*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)

        I30,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(3,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,3,0]= I30*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I31,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(3,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3)  
        Imn[i,3,1]= I31*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I32,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(3,2,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,3,2]= I32*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        I33,errin= sp.integrate.quad(Imn_outer_integ,kmod[0],kmod[-1],args=(3,3,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Imn[i,3,3]= I33*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
    return Imn

#--------------------------------------------------------------------------
def Gmn(m,n,r):    
    if(m==0) and (n==0):
        GMN= (12.0/(r*r) - 158.0 + 100.0*r*r - 42.0*r*r*r*r + (3.0/(r*r*r))*(r*r - 1.0)*(r*r - 1.0)*(r*r - 1.0)*(7.0*r*r + 2.0)*np.log((r + 1.0)/np.abs(r - 1.0)))/3024.0;
    if(m==0) and (n==1):
        GMN= (24.0/(r*r) - 202.0 + 56.0*r*r - 30.0*r*r*r*r + (3.0/(r*r*r))*(r*r - 1.0)*(r*r - 1.0)*(r*r - 1.0)*(5.0*r*r + 4.0)*np.log((r + 1.0)/np.abs(r - 1.0)))/3024.0;
    if(m==0) and (n==2):
        GMN= (2.0*(r*r + 1.0)*(3.0*r*r*r*r - 14.0*r*r + 3.0)/(r*r) - (3.0/(r*r*r))*(r*r - 1.0)*(r*r - 1.0)*(r*r - 1.0)*(r*r - 1.0)*np.log((r + 1.0)/np.abs(r - 1.0)))/224.0;
    if(m==1) and (n==0):
        GMN= (-38.0 +48.0*r*r - 18.0*r*r*r*r + (9.0/r)*(r*r - 1.0)*(r*r - 1.0)*(r*r - 1.0)*np.log((r + 1.0)/np.abs(r - 1.0)))/1008.0;
    if(m==1) and (n==1):
        GMN= (12.0/(r*r) - 82.0 + 4.0*r*r - 6.0*r*r*r*r + (3.0/(r*r*r))*(r*r - 1.0)*(r*r - 1.0)*(r*r - 1.0)*(r*r + 2.0)*np.log((r + 1.0)/np.abs(r - 1.0)))/1008.0;
    if(m==2) and (n==0):
        GMN= (2.0*(9.0 - 109.0*r*r + 63.0*r*r*r*r - 27.0*r*r*r*r*r*r)/(r*r) + (9.0/(r*r*r))*(r*r - 1.0)*(r*r - 1.0)*(r*r - 1.0)*(3.0*r*r + 1.0)*np.log((r + 1.0)/np.abs(r - 1.0)))/672.0;
    return GMN

def Jmn_integ(q,m,n,k,Pl_spline):
    r    = q/k
    if(r==1.0):
        r=(q+0.00001*q)/k
    Pl   = sp.interpolate.splev(np.log10(q),Pl_spline, der=0)
    return Gmn(m,n,r)*10.0**(Pl)

def J_mn(kmod,Pl_spline,ks):
    Jmn=np.zeros((len(ks),2,3))
    for i in range(len(ks)):
        J00,errin= sp.integrate.quad(Jmn_integ,kmod[0],kmod[-1],args=(0,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3)
        Jmn[i,0,0] = J00/(2.0*math.pi*math.pi)
        J01,errin= sp.integrate.quad(Jmn_integ,kmod[0],kmod[-1],args=(0,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3)
        Jmn[i,0,1] = J01/(2.0*math.pi*math.pi)
        J02,errin= sp.integrate.quad(Jmn_integ,kmod[0],kmod[-1],args=(0,2,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Jmn[i,0,2] = J02/(2.0*math.pi*math.pi)

        J10,errin= sp.integrate.quad(Jmn_integ,kmod[0],kmod[-1],args=(1,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Jmn[i,1,0] = J10/(2.0*math.pi*math.pi)
        J11,errin= sp.integrate.quad(Jmn_integ,kmod[0],kmod[-1],args=(1,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        Jmn[i,1,1] = J11/(2.0*math.pi*math.pi)
        J20,errin= sp.integrate.quad(Jmn_integ,kmod[0],kmod[-1],args=(2,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3)
        Jmn[i,1,2] = J20/(2.0*math.pi*math.pi)
    return Jmn

#--------------------------------------------------------------------------
def hmn(m,n,s,r,x,y):
    if (m == 0) and (n == 0):
        if (s == 0):
            numer = 7.0*x + 3.0*r - 10.0*r*x*x;
            return numer/(14.0*r*y*y);
        if (s == 1):
            numer = (7.0*x + 3.0*r - 10.0*r*x*x)*(3.0*x*x - 4.0*r*x + 2.0*r*r - 1.0);
            return numer/(14.0*3.0*r*y*y*y*y);
    if (m == 0) and (n == 1):
        if (s == 0):
            return 1.0;
        if (s == 1):
            numer = (3.0*x*x - 4.0*r*x + 2.0*r*r - 1.0);
            return (numer*numer)/(3.0*3.0*y*y*y*y);
    if (m == 0) and (n == 2):
        if (s == 1):
            numer = (3.0*x*x - 4.0*r*x + 2.0*r*r - 1.0);
            return numer/(3.0*y*y);
    if (m == 1) and (n == 0):
        if (s == 0):
            numer = 7.0*x - r - 6.0*r*x*x;
            return numer/(14.0*r*y*y);
        if (s == 1):
            numer = (7.0*x - r - 6.0*r*x*x)*(3.0*x*x - 4.0*r*x + 2.0*r*r - 1.0);
            return numer/(14.0*3.0*r*y*y*y*y);
    if (m == 1) and (n == 1):
        if (s == 0):
            return x/r;
        if (s == 1):
            numer = (3.0*x*x - 4.0*r*x + 2.0*r*r - 1.0)*x/r;
            return numer/(3.0*y*y);
    if (m == 2) and (n == 0):
       if (s == 0):
           numer = (x*x - 1.0)/2.0#x*x - 1.0;
           #return numer;
           return numer/(y*y);
       if (s == 1):
           numer = (x*x - 1.0)*(3.0*x*x - 4.0*r*x + 2.0*r*r - 1.0);
           #return numer/(3.0*y*y);
           return numer/(6.0*y*y*y*y);#(3.0*y*y*y*y);
    if (m == 3) and (n == 0):
       if (s == 0):
           numer = (2.0*x + r - 3.0*r*x*x)/2.0;#2.0*x + r - 3.0*r*x*x;
           #return numer;
           return numer/(r*y*y);
       if (s == 1):
           numer = (2.0*x + r - 3.0*r*x*x)*(3.0*x*x - 4.0*r*x + 2.0*r*r - 1.0);
           #return numer/(3.0*y*y);
           return numer/(6.0*r*y*y*y*y);#(3.0*r*y*y*y*y);

def Kmn_inner_integ(x,m,n,s,k,r,Pl_spline):
    y    = np.sqrt(1.0+r*r-2.0*r*x)
    Plkq = sp.interpolate.splev(np.log10(k*y), Pl_spline, der=0)
    return hmn(m,n,s,r,x,y)*10.0**(Plkq)

def Kmn_outer_integ(r,m,n,s,k,Pl_spline):
    integ,errin= sp.integrate.quad(Kmn_inner_integ,-1.0,1.0,epsabs=0.0,epsrel=1.0e-3,args=(m,n,s,k,r,Pl_spline))
    Pl   = sp.interpolate.splev(np.log10(k*r),Pl_spline, der=0)
    return r*r*integ*10.0**(Pl)

def K_mn(kmod,Pl_spline,ks):
    KMN=np.zeros((len(ks),3,2))
    KSmn=np.zeros((len(ks),7))
    #norm=KNORm(kmod,Pl_spline)
    for i in range(len(ks)):
        K00,errin = sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(0,0,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KMN[i,0,0]= K00*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi) 
        Ks00,errin= sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(0,0,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KSmn[i,0] = Ks00*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi) 
        
        K01,errin = sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(0,1,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KMN[i,0,1]= K01*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)#-norm
        Ks01,errin= sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(0,1,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KSmn[i,1] = Ks01*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)#-4.0/9.0*norm
        Ks02,errin= sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(0,2,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KSmn[i,2] = Ks02*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)#-2.0/3.0*norm

        K10,errin = sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(1,0,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KMN[i,1,0]= K10*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        Ks10,errin= sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(1,0,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KSmn[i,3] = Ks10*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        
        K11,errin = sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(1,1,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KMN[i,1,1]= K11*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi) 
        Ks11,errin= sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(1,1,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KSmn[i,4] = Ks11*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)

        K20,errin = sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(2,0,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KMN[i,2,0]= K20*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        Ks20,errin= sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(2,0,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KSmn[i,5] = Ks20*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        
        K30,errin = sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(3,0,0,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KMN[i,2,1]= K30*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
        Ks30,errin= sp.integrate.quad(Kmn_outer_integ,kmod[0],kmod[-1],args=(3,0,1,ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        KSmn[i,6] = Ks30*ks[i]*ks[i]*ks[i]/(4.0*math.pi*math.pi)
    return KMN ,KSmn

#--------------------------------------------------------------------------
def pk_integ(r,kval,Pl_spline):
    P_lin = sp.interpolate.splev(np.log10(r*kval),Pl_spline, der=0)
    return r*r*10.0**(P_lin)*10.0**(P_lin)

def KNORm(kmod,Pl_spline,ks):#KNORm(kmod,Pl_spline):
    xsa=np.zeros(len(ks))
    for i in range(len(ks)):
        integ,errin = sp.integrate.quad(pk_integ,kmod[0],kmod[len(kmod)-1],args=(ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3)
        xsa[i]=ks[i]*ks[i]*ks[i]*integ/(2.0*math.pi*math.pi)
    return xsa

def SIGMA3_inner_integ(x,r):
    y     = np.sqrt(1.0+r*r-2.0*r*x)
    numer = (2.0/7.0)*(x*x - 1.0)*(3.0*x*x - 4.0*r*x + 2.0*r*r - 1.0)
    return numer/(3.0*y*y) + 8.0/63.0
    
def SIGMA3_outter_integ(r,k,Pl_spline):  
    integ,errin= sp.integrate.quad(SIGMA3_inner_integ,-1.0,1.0,epsabs=0.0,epsrel=1.0e-4,args=(r))
    Pl   = sp.interpolate.splev(np.log10(k*r),Pl_spline, der=0)
    return integ*r*r*10.0**(Pl)

def SIGMA3(kmod,Pl_spline,ks):
    SIGMAs=np.zeros(len(ks))
    for i in range(len(ks)):
        integ,errin= sp.integrate.quad(SIGMA3_outter_integ,kmod[0],kmod[-1],args=(ks[i],Pl_spline),epsabs=0.0,epsrel=1.0e-3) 
        SIGMAs[i]=integ*(105.0*ks[i]*ks[i]*ks[i])/(64.0*math.pi*math.pi)
    return SIGMAs


# 3. calculate model mom-PS:-----------------------------------------------
# this function is to calculate the model PS
# from the linear-theory-PS,Pkmod_Linear and the
# theory-PS of velocity divergance,Pkmod_div.
# Pkmod_Linear and Pkmod_div should have same size,
# and they should cooresponds to same kmod.
def Pk_MOD(params,sigma8_fid,PT,PS_type,Nparms,Growthz,Damp_type,Domultipo):
    if (PS_type=='mom'):
        if(Damp_type=='sep'):
            b1vsigma8, fsigma8, b2vsigma8, sigmav_v1, sigmav_v2, sigmav_v3 = params  # ---->> Lab.1
        else:
            b1vsigma8, fsigma8, b2vsigma8, sigmav_v1 = params # ---->> Lab.2
            sigmav_v2=sigmav_v1 # ---->> Lab.2
            sigmav_v3=sigmav_v1 # ---->> Lab.2     
        f = fsigma8/sigma8_fid
        sigma8rat = Growthz**2*(sigma8_fid/sigma8_fid)**2
        b1v = b1vsigma8/sigma8_fid
        b2v = b2vsigma8/sigma8_fid
        bsv = -4.0/7.0*(b1v-1.0)
        b3nlv = 32.0/315.0*(b1v-1.0)
        if(Damp_type=='sep'):
            sigmav_v1 /= (f*f)# ---->> Lab.1
            sigmav_v2 /= (f*f)# ---->> Lab.1
            sigmav_v3 /= (f*f)# ---->> Lab.1
    if (PS_type=='den'): 
        if(Damp_type=='sep'):
            b1sigma8,  fsigma8,  b2sigma8,  sigma_v1,  sigma_v2,  sigma_v3 = params # ---->> Lab.1
        else:
            b1sigma8,  fsigma8,  b2sigma8,  sigma_v1 = params # ---->> Lab.2
            sigma_v2=sigma_v1 # ---->> Lab.2
            sigma_v3=sigma_v1 # ---->> Lab.2     
        f = fsigma8/sigma8_fid
        sigma8rat = Growthz**2*(sigma8_fid/sigma8_fid)**2
        b1 = b1sigma8/sigma8_fid
        b2 = b2sigma8/sigma8_fid
        bs = -4.0/7.0*(b1-1.0)
        b3nl = 32.0/315.0*(b1-1.0)
        if(Damp_type=='sep'):
            sigma_v1 /= (f*f)# ---->> Lab.1
            sigma_v2 /= (f*f)# ---->> Lab.1
            sigma_v3 /= (f*f)# ---->> Lab.1
    if(PS_type=='den+mom'):
        if(Nparms==8):
            if(Damp_type=='sep'):
                b1sigma8,  fsigma8,  b2sigma8,  sigma_v1,  sigma_v2,  sigma_v3, b1vsigma8, b2vsigma8, sigmav_v1, sigmav_v2, sigmav_v3 = params # ---->> Lab.1
            else:
                b1sigma8,  fsigma8,  b2sigma8,  sigma_v1,  b1vsigma8, b2vsigma8, sigmav_v1 = params # ---->> Lab.2
                sigma_v2=sigma_v1 # ---->> Lab.2
                sigma_v3=sigma_v1 # ---->> Lab.2
                sigmav_v2=sigmav_v1 # ---->> Lab.2
                sigmav_v3=sigmav_v1 # ---->> Lab.2     
        if(Nparms==5):
            if(Damp_type=='sep'):
                b1sigma8, fsigma8, b2sigma8, sigma_v1,  sigma_v2,  sigma_v3 = params # ---->> Lab.1
            else:
                b1sigma8, fsigma8, b2sigma8, sigma_v1 = params # ---->> Lab.2
                sigma_v2=sigma_v1 # ---->> Lab.2
                sigma_v3=sigma_v1 # ---->> Lab.2            
            b1vsigma8 = b1sigma8
            b2vsigma8 = b2sigma8
            sigmav_v1 = sigma_v1
            sigmav_v2 = sigma_v2
            sigmav_v3 = sigma_v3
        b1 = b1sigma8/sigma8_fid
        b2 = b2sigma8/sigma8_fid
        b1v = b1vsigma8/sigma8_fid
        b2v = b2vsigma8/sigma8_fid
        f = fsigma8/sigma8_fid
        sigma8rat = Growthz**2*(sigma8_fid/sigma8_fid)**2
        bs = -4.0/7.0*(b1-1.0)
        b3nl = 32.0/315.0*(b1-1.0) 
        bsv = -4.0/7.0*(b1v-1.0)
        b3nlv = 32.0/315.0*(b1v-1.0)
        if(Damp_type=='sep'):
            sigma_v1 /= (f*f)# ---->> Lab.1
            sigma_v2 /= (f*f)# ---->> Lab.1
            sigma_v3 /= (f*f)# ---->> Lab.1
            sigmav_v1 /= (f*f)# ---->> Lab.1
            sigmav_v2 /= (f*f)# ---->> Lab.1
            sigmav_v3 /= (f*f)# ---->> Lab.1

    mu = np.linspace(0.0, 1.0, 100)
    if(Damp_type=='sep'):
        sigma_v = 1.0/(6.0*math.pi**2)*sp.integrate.simps(sigma8rat*(PT[1,0:] + sigma8rat*(2.0*PT[7,0:] + 6.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[22,0:])), PT[0,0:]) # ---->> Lab.1
    else:
        sigma_v = 0.0 # ---->> Lab.2

    if (PS_type=='den') or (PS_type=='den+mom'):
        P_00 = np.tile(b1*b1*sigma8rat*(PT[1,0:] + 2.0*sigma8rat*(PT[2,0:] + 3.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[18,0:])) + 2.0*b1*sigma8rat**2*(b2*PT[24,0:] + bs*PT[25,0:] + b3nl*PT[1,0:]*PT[37,0:]) + sigma8rat**2*(1.0/2.0*b2**2*PT[26,0:] + 1.0/2.0*bs**2*PT[27,0:] + b2*bs*PT[28,0:]), (len(mu),1)).T
        P_01 = np.tile(f*b1*sigma8rat*(PT[1,0:] + 2.0*sigma8rat*(PT[3,0:] + b1*PT[6,0:] + 3.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*(PT[19,0:] + b1*PT[21,0:])) - b2*sigma8rat*PT[31,0:] - bs*sigma8rat*PT[32,0:]) - f*sigma8rat**2*(b2*PT[29,0:] + bs*PT[30,0:] + b3nl*PT[1,0:]*PT[37,0:]), (len(mu),1)).T
        P_02 = np.tile(f*f*sigma8rat**2*(b1*PT[4,0:] + 2.0*b1*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[20,0:] - b2*PT[33,0:] - bs*PT[34,0:]), (len(mu),1)).T - (f*f*(sigma_v+sigma_v1)*PT[0,0:]*PT[0,0:]*(P_00.T)).T + np.outer(f*f*sigma8rat**2*(b1*PT[10,0:] + 2.0*b1*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[23,0:] - b2*PT[35,0:] - bs*PT[36,0:]), mu**2)
        P_03 = (-f*f*PT[0,0:]*PT[0,0:]*(sigma_v+sigma_v2)*(P_01.T)).T
        P_04 = np.tile(-1.0/2.0*f*f*f*f*b1*PT[0,0:]*PT[0,0:]*(sigma_v+sigma_v3)*sigma8rat**2*(PT[4,0:] + 2.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[20,0:]), (len(mu),1)).T + (1.0/4.0*f*f*f*f*b1*b1*PT[0,0:]*PT[0,0:]*PT[0,0:]*PT[0,0:]*(P_00.T)*((sigma_v+sigma_v3)**2 + 1.0/(24.0*math.pi*math.pi)*(sigma8rat**2*sp.integrate.simps(PT[13,0:]/(PT[0,0:]*PT[0,0:]),PT[0,0:]) + 2.0*sp.integrate.simps(PT[16,0:]/(PT[0,0:]*PT[0,0:]),PT[0,0:])/3.0 + sp.integrate.simps(PT[17,0:]/(PT[0,0:]*PT[0,0:]),PT[0,0:])/5.0))).T + np.outer(-1.0/2.0*f*f*f*f*b1*PT[0,0:]*PT[0,0:]*(sigma_v+sigma_v3)*sigma8rat**2*(PT[10,0:] + 2.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[23,0:]), mu**2)
        P_11 = np.tile(f*f*b1*b1*sigma8rat**2*PT[15,0:], (len(mu),1)).T + np.outer(f*f*sigma8rat*(PT[1,0:] + sigma8rat*(2.0*PT[7,0:] + 4.0*b1*PT[12,0:] + b1*b1*PT[9,0:] + 6.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*(PT[22,0:] + 2.0*b1*PT[21,0:]))), mu**2)
        P_12 = np.tile(f*f*f*sigma8rat**2*(PT[8,0:] - b1*PT[5,0:] + 2.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[20,0:]), (len(mu),1)).T - (f*f*PT[0,0:]*PT[0,0:]*(sigma_v+sigma_v1)*(P_01.T)).T + np.outer(f*f*f*sigma8rat**2*(PT[11,0:] - b1*PT[14,0:] + 2.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[23,0:]), mu**2)
        P_13 = np.tile(-f*f*PT[0,0:]*PT[0,0:]*(sigma_v+sigma_v1)*f*f*b1*b1*sigma8rat**2*PT[15,0:], (len(mu),1)).T + np.outer(-f*f*f*f*sigma8rat*PT[0,0:]*PT[0,0:]*((sigma_v+sigma_v1)*b1*b1*sigma8rat*PT[9,0:] + (sigma_v+sigma_v2)*(PT[1,0:] + sigma8rat*(2.0*PT[7,0:] + 4.0*b1*PT[12,0:] + 6.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*(PT[22,0:] + 2.0*b1*PT[21,0:])))), mu**2)
        P_22 = np.tile(1.0/4.0*f*f*f*f*sigma8rat**2*PT[13,0:], (len(mu),1)).T + np.outer(1.0/2.0*f*f*f*f*sigma8rat**2*PT[16,0:],mu**2) + np.outer(1.0/4.0*f*f*f*f*sigma8rat**2*PT[17,0:], mu**4) + (f*f*f*f*PT[0,0:]*PT[0,0:]*PT[0,0:]*PT[0,0:]*(sigma_v + sigma_v1)**2*(P_00.T)).T - (2.0*f*f*PT[0,0:]*PT[0,0:]*(sigma_v + sigma_v1)*(P_02.T)).T + np.tile(f*f*f*f*PT[0,0:]*PT[0,0:]*(sigma_v + sigma_v1)*sigma8rat**2*(b2*PT[33,0:] + bs*PT[34,0:]), (len(mu),1)).T + np.outer(f*f*f*f*PT[0,0:]*PT[0,0:]*(sigma_v + sigma_v1)*sigma8rat**2*(b2*PT[35,0:] + bs*PT[36,0:]),mu**2)
        P_den = P_00 + mu**2*(2.0*P_01 + P_02 + P_11) + mu**4*(P_03 + P_04 + P_12 + P_13 + 1.0/4.0*P_22)
        P_0den = sp.integrate.simps(P_den,mu,axis=1)
        if(Domultipo):
            P_2den   = sp.integrate.simps(3.0*mu**2*P_den,mu,axis=1)
            #P_4den   = sp.integrate.simps(35.0*mu**4*P_den,mu,axis=1)       
    if (PS_type=='mom') or (PS_type=='den+mom'):
        P_00 = np.tile(b1v*b1v*sigma8rat*(PT[1,0:] + 2.0*sigma8rat*(PT[2,0:] + 3.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[18,0:])) + 2.0*b1v*sigma8rat**2*(b2v*PT[24,0:] + bsv*PT[25,0:] + b3nlv*PT[1,0:]*PT[37,0:]) + sigma8rat**2*(1.0/2.0*b2v**2*PT[26,0:] + 1.0/2.0*bsv**2*PT[27,0:] + b2v*bsv*PT[28,0:]), (len(mu),1)).T
        P_01 = np.tile(f*b1v*sigma8rat*(PT[1,0:] + 2.0*sigma8rat*(PT[3,0:] + b1v*PT[6,0:] + 3.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*(PT[19,0:] + b1v*PT[21,0:])) - b2v*sigma8rat*PT[31,0:] - bsv*sigma8rat*PT[32,0:]) - f*sigma8rat**2*(b2v*PT[29,0:] + bsv*PT[30,0:] + b3nlv*PT[1,0:]*PT[37,0:]), (len(mu),1)).T
        P_02 = np.tile(f*f*sigma8rat**2*(b1v*PT[4,0:] + 2.0*b1v*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[20,0:] - b2v*PT[33,0:] - bsv*PT[34,0:]), (len(mu),1)).T - (f*f*(sigma_v+sigmav_v1)*PT[0,0:]*PT[0,0:]*(P_00.T)).T + np.outer(f*f*sigma8rat**2*(b1v*PT[10,0:] + 2.0*b1v*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[23,0:] - b2v*PT[35,0:] - bsv*PT[36,0:]), mu**2) 
        P_03 = (-f*f*PT[0,0:]*PT[0,0:]*(sigma_v+sigmav_v2)*(P_01.T)).T
        P_04 = np.tile(-1.0/2.0*f*f*f*f*b1v*PT[0,0:]*PT[0,0:]*(sigma_v+sigmav_v3)*sigma8rat**2*(PT[4,0:] + 2.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[20,0:]), (len(mu),1)).T + (1.0/4.0*f*f*f*f*b1v*b1v*PT[0,0:]*PT[0,0:]*PT[0,0:]*PT[0,0:]*(P_00.T)*((sigma_v+sigmav_v3)**2 + 1.0/(24.0*math.pi*math.pi)*(sigma8rat**2*sp.integrate.simps(PT[13,0:]/(PT[0,0:]*PT[0,0:]),PT[0,0:]) + 2.0*sp.integrate.simps(PT[16,0:]/(PT[0,0:]*PT[0,0:]),PT[0,0:])/3.0 + sp.integrate.simps(PT[17,0:]/(PT[0,0:]*PT[0,0:]),PT[0,0:])/5.0))).T + np.outer(-1.0/2.0*f*f*f*f*b1v*PT[0,0:]*PT[0,0:]*(sigma_v+sigmav_v3)*sigma8rat**2*(PT[10,0:] + 2.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[23,0:]), mu**2) 
        P_11 = np.tile(f*f*b1v*b1v*sigma8rat**2*PT[15,0:], (len(mu),1)).T + np.outer(f*f*sigma8rat*(PT[1,0:] + sigma8rat*(2.0*PT[7,0:] + 4.0*b1v*PT[12,0:] + b1v*b1v*PT[9,0:] + 6.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*(PT[22,0:] + 2.0*b1v*PT[21,0:]))), mu**2) 
        P_12 = np.tile(f*f*f*sigma8rat**2*(PT[8,0:] - b1v*PT[5,0:] + 2.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[20,0:]), (len(mu),1)).T - (f*f*PT[0,0:]*PT[0,0:]*(sigma_v+sigmav_v1)*(P_01.T)).T + np.outer(f*f*f*sigma8rat**2*(PT[11,0:] - b1v*PT[14,0:] + 2.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*PT[23,0:]), mu**2)
        P_13 = np.tile(-f*f*PT[0,0:]*PT[0,0:]*(sigma_v+sigmav_v1)*f*f*b1v*b1v*sigma8rat**2*PT[15,0:], (len(mu),1)).T + np.outer(-f*f*f*f*sigma8rat*PT[0,0:]*PT[0,0:]*((sigma_v+sigmav_v1)*b1v*b1v*sigma8rat*PT[9,0:] + (sigma_v+sigmav_v2)*(PT[1,0:] + sigma8rat*(2.0*PT[7,0:] + 4.0*b1v*PT[12,0:] + 6.0*PT[0,0:]*PT[0,0:]*PT[1,0:]*(PT[22,0:] + 2.0*b1v*PT[21,0:])))), mu**2) 
        P_22 = np.tile(1.0/4.0*f*f*f*f*sigma8rat**2*PT[13,0:], (len(mu),1)).T + np.outer(1.0/2.0*f*f*f*f*sigma8rat**2*PT[16,0:],mu**2) + np.outer(1.0/4.0*f*f*f*f*sigma8rat**2*PT[17,0:], mu**4) + (f*f*f*f*PT[0,0:]*PT[0,0:]*PT[0,0:]*PT[0,0:]*(sigma_v + sigmav_v1)**2*(P_00.T)).T - (2.0*f*f*PT[0,0:]*PT[0,0:]*(sigma_v + sigmav_v1)*(P_02.T)).T + np.tile(f*f*f*f*PT[0,0:]*PT[0,0:]*(sigma_v + sigmav_v1)*sigma8rat**2*(b2v*PT[33,0:] + bsv*PT[34,0:]), (len(mu),1)).T + np.outer(f*f*f*f*PT[0,0:]*PT[0,0:]*(sigma_v + sigmav_v1)*sigma8rat**2*(b2v*PT[35,0:] + bsv*PT[36,0:]),mu**2)
        P_mom = ((1.0e4)/(1.0**2)/(PT[0,0:]*PT[0,0:])*(P_11 + mu**2*(2.0*P_12 + 3.0*P_13 + P_22)).T).T
        P_0mom = sp.integrate.simps(P_mom,mu,axis=1)
        if(Domultipo):
            P_2mom = sp.integrate.simps(3.0*mu**2*P_mom,mu,axis=1)
            #P_4mom = sp.integrate.simps(35.0*mu**4*P_mom,mu,axis=1)
    if(not Domultipo):
        if (PS_type=='den'):
            P_model = P_0den
        if (PS_type=='den+mom'):
            P_model = np.concatenate([P_0den,P_0mom])
        if (PS_type=='mom'):
            P_model = P_0mom
    if( Domultipo):
        if (PS_type=='den'):
            #P_model = np.concatenate([P_0den,P_2den,P_4den])
            P_model = np.concatenate([P_0den,P_2den])
        if (PS_type=='den+mom'):
            #P_model = np.concatenate([P_0den,P_2den,P_4den,P_0mom,P_2mom,P_4mom])
            P_model = np.concatenate([P_0den,P_2den,P_0mom,P_2mom])
        if (PS_type=='mom'):
            #P_model = np.concatenate([P_0mom,P_2mom,P_4mom])
            P_model = np.concatenate([P_0mom,P_2mom])
    return P_model


# 4. calculate the likelihood function and chi^2:--------------------------
# Sig8_Pkmod
# kmod,Pkmod_Linear,Pkmod_div: should have same size. un-convoluted.
# k_obs,Pk_obs: should have same size
# WF_Kobs_Kmod:  WF_kobskmod[k_obs][kmod] is used to convolute Pk_MOD
#               to match Pk_obs.
# Cov_inv[i][j]: should have the size(k_obs)*size(k_obs)
def Target_Fun(params,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo):
    Pk_modss = Pk_MOD(params,Sig8_fid,PT,PS_type,Nparms,Growthz,Damp_type,Domultipo)
    if(PS_type=='den+mom'):
        if(not Domultipo):
            Pk_mod   = np.zeros(len(k_obs)*2)    # kmod=PT[0,:] Pkmod_L=PT[1,:]     
            P_spline = sp.interpolate.splrep(PT[0,:],Pk_modss[0:len(PT[0,:])],s=0) # kmod=PT[0,:] Pkmod_L=PT[1,:]
            Pk_mods  = sp.interpolate.splev(kmod_conv, P_spline)
            if(WFCon_type=='Ross'):Pk_mod[0:len(k_obs)]= Pk_CONV(k_obs,WF_Kobs_Kmod,Pk_mods,WF_rand[0],WF_rand[1])#size(kobs)        
            if(WFCon_type=='Blake'):Pk_mod[0:len(k_obs)] = Pk_CONV_new(WF_Kobs_Kmod,Pk_mods,Domultipo)
            P_spline = sp.interpolate.splrep(PT[0,:],Pk_modss[len(PT[0,:]):2*len(PT[0,:])],s=0)
            Pk_mods  = sp.interpolate.splev(kmod_conv, P_spline)
            if(WFCon_type=='Ross'):Pk_mod[len(k_obs):2*len(k_obs)]= Pk_CONV(k_obs,WF_Kobs_Kmod,Pk_mods,WF_rand[0],WF_rand[1])#size(kobs)
            if(WFCon_type=='Blake'):Pk_mod[len(k_obs):2*len(k_obs)]= Pk_CONV_new(WF_Kobs_Kmod,Pk_mods,Domultipo)
        if(Domultipo):
            Nic=Nmnpo*2
            Pk_mod   = np.zeros(len(k_obs))    # kmod=PT[0,:] Pkmod_L=PT[1,:]     
            
            P_spline_den0 = sp.interpolate.splrep(PT[0,:],Pk_modss[0:(len(Pk_modss)//Nic)],s=0)
            Pk_mods_den0  = sp.interpolate.splev(kmod_conv, P_spline_den0)
            P_spline_den2 = sp.interpolate.splrep(PT[0,:],Pk_modss[(len(Pk_modss)//Nic):(len(Pk_modss)//Nic*2)],s=0)
            Pk_mods_den2  = sp.interpolate.splev(kmod_conv, P_spline_den2)
            
            P_spline_mom0 = sp.interpolate.splrep(PT[0,:],Pk_modss[(len(Pk_modss)//Nic*2):(len(Pk_modss)//Nic*3)],s=0)
            Pk_mods_mom0  = sp.interpolate.splev(kmod_conv, P_spline_mom0)
            P_spline_mom2 = sp.interpolate.splrep(PT[0,:],Pk_modss[(len(Pk_modss)//Nic*3):(len(Pk_modss)//Nic*4)],s=0)
            Pk_mods_mom2  = sp.interpolate.splev(kmod_conv, P_spline_mom2)            
            
            Pk_mods_den   = np.concatenate([Pk_mods_den0,Pk_mods_den2]) #,Pk_mods4]
            Pk_mod_den    = Pk_CONV_new(WF_Kobs_Kmod,Pk_mods_den,Domultipo)
            Pk_mods_mom   = np.concatenate([Pk_mods_mom0,Pk_mods_mom2]) #,Pk_mods4]
            Pk_mod_mom    = Pk_CONV_new(WF_Kobs_Kmod,Pk_mods_mom,Domultipo)
            
            Pk_mod        = np.concatenate([Pk_mod_den,Pk_mod_mom])
    else:
        if(not Domultipo):
            P_spline = sp.interpolate.splrep(PT[0,:],Pk_modss,s=0)
            Pk_mods  = sp.interpolate.splev(kmod_conv, P_spline)
            if(WFCon_type=='Ross'):Pk_mod   = Pk_CONV(k_obs,WF_Kobs_Kmod,Pk_mods,WF_rand[0],WF_rand[1])#size(kobs)
            if(WFCon_type=='Blake'):Pk_mod   = Pk_CONV_new(WF_Kobs_Kmod,Pk_mods,Domultipo)
        if(Domultipo):
            P_spline0 = sp.interpolate.splrep(PT[0,:],Pk_modss[0:(len(Pk_modss)//Nmnpo)],s=0)
            Pk_mods0  = sp.interpolate.splev(kmod_conv, P_spline0)
            P_spline2 = sp.interpolate.splrep(PT[0,:],Pk_modss[(len(Pk_modss)//Nmnpo):(len(Pk_modss)//(Nmnpo-1))],s=0)
            Pk_mods2  = sp.interpolate.splev(kmod_conv, P_spline2)
            #P_spline4 = sp.interpolate.splrep(PT[0,:],Pk_modss[len(Pk_modss)//(Nmnpo-1):len(Pk_modss)//(Nmnpo-2)],s=0)
            #Pk_mods4  = sp.interpolate.splev(kmod_conv, P_spline4)
            Pk_mods   = np.concatenate([Pk_mods0,Pk_mods2]) #,Pk_mods4]
            Pk_mod    = Pk_CONV_new(WF_Kobs_Kmod,Pk_mods,Domultipo)
    return Pk_mod

def CHI2(params,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo):
    Pk_mod=Target_Fun(params,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
    VC=np.dot((Pk_obs[ind_fit]-Pk_mod[ind_fit]),Cov_inv)
    chi_squared=np.dot(VC,(Pk_obs[ind_fit]-Pk_mod[ind_fit]))
    return chi_squared


def Box_CoxFUN(params,Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo):
    Pk_mod=Target_Fun(params,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
    XC=Pk_mod[ind_fit]+BC_d
    Pk_mod=np.zeros(len(XC))
    for i in range(len(XC)):
        if(XC[i]<=0):
            Pk_mod[i]=(-abs(XC[i]) **BC_nu[i]-1.0)/BC_nu[i]
        else:
            Pk_mod[i]=(XC[i] **BC_nu[i]-1.0)/BC_nu[i]
    #Pk_mod  =((Pk_mod[ind_fit]+BC_d)**BC_nu-1.0)/BC_nu
    VC   = np.dot((Pk_obs-Pk_mod),Cov_inv)
    chi2 = np.dot(VC,(Pk_obs-Pk_mod))
    Pb   = np.log(  Cp*(1.0+chi2/(Nmock-1.0))) * (-Nmock/2.0)   
    return -Pb



# 5. the posterior and prior of MCMC:--------------------------------------
def lnprior(params,PS_type,Nparms,Damp_type):
    if (PS_type=='mom'):
        if(Damp_type=='sep'):
            b1vsigma8, fsigma8, b2vsigma8, sigmav_v1, sigmav_v2, sigmav_v3 = params  # ---->> Lab.1
            # Flat prior for fsigma8 between 0.0 and 2.0
            if (0.0 < fsigma8 <= 2.0):
                fsigma8prior = 2.0
            else:
                return -np.inf
            # Flat prior for b1sigma8 between 0.2 and 1.7
            if (0.2 <= b1vsigma8 <= 5.0):
                b1sigma8prior = 1.0/1.5
            else:
                return -np.inf
            # Flat prior for b2sigma8 between 0.2 and 1.7
            if (-2.0 <= b2vsigma8 <= 10.0):
                b2sigma8prior = 1.0/1.5
            else:
                return -np.inf
            # Flat prior for sigma8 between 0.4 and 1.2
            if (-100.0 < sigmav_v1 < 100.0):
                sigmagprior = 1.0/15.0
            else:
                return -np.inf
            # Flat prior for sigma8 between 0.4 and 1.2
            if (-1000.0 < sigmav_v2 < 1000.0):
                sigmagprior = 1.0/15.0
            else:
                return -np.inf
            # Flat prior for sigma8 between 0.4 and 1.2
            if (-1000.0 < sigmav_v3 < 1000.0):
                sigmagprior = 1.0/15.0
            else:
                return -np.inf
        else:
            b1vsigma8, fsigma8, b2vsigma8, sigmav_v1 = params # ---->> Lab.2
            # Flat prior for fsigma8 between 0.0 and 2.0
            if (0.0 < fsigma8 <= 2.0):
                fsigma8prior = 2.0
            else:
                return -np.inf
            # Flat prior for b1sigma8 between 0.2 and 1.7
            if (0.2 <= b1vsigma8 <= 5.0):
                b1sigma8prior = 1.0/1.5
            else:
                return -np.inf
            # Flat prior for b2sigma8 between 0.2 and 1.7
            if (-2.0 <= b2vsigma8 <= 10.0):
                b2sigma8prior = 1.0/1.5
            else:
                return -np.inf
            # Flat prior for sigma8 between 0.4 and 1.2
            if (0.0 < sigmav_v1 < 100.0):
                sigmagprior = 1.0/15.0
            else:
                return -np.inf
    else:
        if(Nparms==8):
            if(Damp_type=='sep'):
                b1sigma8,  fsigma8,  b2sigma8,  sigma_v1,  sigma_v2,  sigma_v3, b1vsigma8, b2vsigma8, sigmav_v1, sigmav_v2, sigmav_v3 = params # ---->> Lab.1
                # Flat prior for fsigma8 between 0.0 and 2.0
                if (0.0 < fsigma8 <= 2.0):
                    fsigma8prior = 2.0
                else:
                    return -np.inf
                # Flat prior for b1sigma8 between 0.2 and 1.7
                if (0.2 <= b1vsigma8 <= 5.0):
                    b1sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for b2sigma8 between 0.2 and 1.7
                if (-2.0 <= b2vsigma8 <= 10.0):
                    b2sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for b1sigma8 between 0.2 and 1.7
                if (0.2 <= b1sigma8 <= 5.0):
                    b1sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for b2sigma8 between 0.2 and 1.7
                if (-2.0 <= b2sigma8 <= 10.0):
                    b2sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                if (-100.0 < sigmav_v1 < 100.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
                # Flat prior for sigma8 between 0.4 and 1.2
                if (-1000.0 < sigmav_v2 < 1000.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
                # Flat prior for sigma8 between 0.4 and 1.2
                if (-1000.0 < sigmav_v3 < 1000.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
                # Flat prior for sigma8 between 0.4 and 1.2
                if (-100.0 < sigma_v1 < 100.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
                # Flat prior for sigma8 between 0.4 and 1.2
                if (-1000.0 < sigma_v2 < 1000.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
                # Flat prior for sigma8 between 0.4 and 1.2
                if (-1000.0 < sigma_v3 < 1000.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf                    
            else:
                b1sigma8,  fsigma8,  b2sigma8,  sigma_v1,  b1vsigma8, b2vsigma8, sigmav_v1 = params # ---->> Lab.2
                # Flat prior for fsigma8 between 0.0 and 2.0
                if (0.0 < fsigma8 <= 2.0):
                    fsigma8prior = 2.0
                else:
                    return -np.inf
                # Flat prior for b1sigma8 between 0.2 and 1.7
                if (0.2 <= b1vsigma8 <= 5.0):
                    b1sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for b2sigma8 between 0.2 and 1.7
                if (-2.0 <= b2vsigma8 <= 10.0):
                    b2sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for b1sigma8 between 0.2 and 1.7
                if (0.2 <= b1sigma8 <= 5.0):
                    b1sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for b2sigma8 between 0.2 and 1.7
                if (-2.0 <= b2sigma8 <= 10.0):
                    b2sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                if (0.0 < sigmav_v1 < 100.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
                if (0.0 < sigma_v1 < 100.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
        if(Nparms==5) or (PS_type=='den'):
            if(Damp_type=='sep'):
                b1sigma8, fsigma8, b2sigma8, sigma_v1,  sigma_v2,  sigma_v3 = params # ---->> Lab.1
                # Flat prior for fsigma8 between 0.0 and 2.0
                if (0.0 < fsigma8 <= 2.0):
                    fsigma8prior = 2.0
                else:
                    return -np.inf
                # Flat prior for b1sigma8 between 0.2 and 1.7
                if (0.2 <= b1sigma8 <= 5.0):
                    b1sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for b2sigma8 between 0.2 and 1.7
                if (-2.0 <= b2sigma8 <= 10.0):
                    b2sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for sigma8 between 0.4 and 1.2
                if (-100.0 < sigma_v1 < 100.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
                # Flat prior for sigma8 between 0.4 and 1.2
                if (-1000.0 < sigma_v2 < 1000.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
                # Flat prior for sigma8 between 0.4 and 1.2
                if (-1000.0 < sigma_v3 < 1000.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
            else:
                b1sigma8, fsigma8, b2sigma8, sigma_v1 = params # ---->> Lab.2
                # Flat prior for fsigma8 between 0.0 and 2.0
                if (0.0 < fsigma8 <= 2.0):
                    fsigma8prior = 2.0
                else:
                    return -np.inf
                # Flat prior for b1sigma8 between 0.2 and 1.7
                if (0.2 <= b1sigma8 <= 5.0):
                    b1sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                # Flat prior for b2sigma8 between 0.2 and 1.7
                if (-2.0 <= b2sigma8 <= 10.0):
                    b2sigma8prior = 1.0/1.5
                else:
                    return -np.inf
                if (0.0 < sigma_v1 < 100.0):
                    sigmagprior = 1.0/15.0
                else:
                    return -np.inf
    return 0.0
# 5.1: the post of MCMC:
def lnpost_chi2(params,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo):
    prior = lnprior(params,PS_type,Nparms,Damp_type)
    if not np.isfinite(prior):
        return -np.inf
    like = -0.5* CHI2(params,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
    return prior + like
# 5.2: the post of MCMC for box-cox trans:
def lnpost_bc(params,Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo):
    prior = lnprior(params,PS_type,Nparms,Damp_type)
    if not np.isfinite(prior):
        return -np.inf
    like = Box_CoxFUN(params,Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
    return prior - like

    
    
# 6 the parameter estimation main code:------------------------------------
def Param_Estimateprep( ks,Pks,out_dir ):  
    #Linear spectra
    pars = camb.CAMBparams()
    pars.set_cosmology(H0=67.27,ombh2=0.022, omch2=0.1198)
    pars.set_dark_energy() #re-set defaults
    pars.InitPower.set_params(As=2.114940245149156e-09,ns=0.9645)
    pars.set_matter_power(redshifts=[0.], kmax=100.0)
    pars.NonLinear = model.NonLinear_none
    results = camb.get_results(pars)
    kh, z, pk = results.get_matter_power_spectrum(minkh=1e-4, maxkh=100.0, npoints = 692)
    print( 'sigma8_fid_integ = ',results.get_sigma8())
    Pl_spline = sp.interpolate.splrep(np.log10(kh),np.log10(pk[0,:]), s=0)
    #infile=np.loadtxt('/Users/fei/Downloads/camb_linear_waves_matterpower_linear.dat')
    #kh=infile[:,0]#from CAMB: k_linear = k_nonlinear
    #pk=infile[:,1]    
    #Pl_spline = sp.interpolate.splrep(np.log10(kh),np.log10(pk), s=0)
    # integrations:
    print( 'Integration-Imn')
    Imn=I_mn(kh,Pl_spline,ks)
    print( 'Integration-Jmn')
    Jmn=J_mn(kh,Pl_spline,ks)
    print( 'Integration-Kmn')
    Kmn,Ksmn=K_mn(kh,Pl_spline,ks)
    print( 'Integration-Sigma3')
    SIGMA_3=SIGMA3(kh,Pl_spline,ks)
    print( 'Integration-norm')
    Intg_norm=KNORm(kh,Pl_spline,ks)
    # outputs:
    I00=Imn[:,0,0]   ; I01=Imn[:,0,1]   ; I02=Imn[:,0,2]   ; I03=Imn[:,0,3]
    I10=Imn[:,1,0]   ; I11=Imn[:,1,1]   ; I12=Imn[:,1,2]   ; I13=Imn[:,1,3]
    I20=Imn[:,2,0]   ; I21=Imn[:,2,1]   ; I22=Imn[:,2,2]   ; I23=Imn[:,2,3]
    I30=Imn[:,3,0]   ; I31=Imn[:,3,1]   ; I32=Imn[:,3,2]   ; I33=Imn[:,3,3]
    J00=Jmn[:,0,0]   ; J01=Jmn[:,0,1]   ; J02=Jmn[:,0,2]   ; J10=Jmn[:,1,0] 
    J11=Jmn[:,1,1]   ; J20=Jmn[:,1,2]       
    K00=Kmn[:,0,0]   ; K01=Kmn[:,0,1]   
    K10=Kmn[:,1,0]   ; K11=Kmn[:,1,1]
    K20=Kmn[:,2,0]   ; K30=Kmn[:,2,1]       
    Ks00=Ksmn[:,0]   ; Ks01=Ksmn[:,1]   ; Ks02=Ksmn[:,2]   ; Ks10=Ksmn[:,3]        
    Ks11=Ksmn[:,4]   ; Ks20=Ksmn[:,5]   ; Ks30=Ksmn[:,6]
    #OUT=[kmod,Pk,I00, I01, I02, I03, I10, I11, I12, I13, 
    #     I20, I21, I22, I23, I30, I31, I32, I33, J00, J01, J02, J10, J11, J20, K00, Ks00, 
    #     K01, Ks01,Ks02,K10,  Ks10,K11, Ks11, K20, Ks20, K30, Ks30, SIGMA_3, norm]
    outfile    = open(out_dir, 'w')
    for i in range(len(ks)):
       outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n"% (ks[i],Pks[i],   I00[i],  I01[i],  I02[i],  I03[i],  I10[i],  I11[i],  I12[i],  I13[i],  I20[i],  I21[i],  I22[i],  I23[i],  I30[i],  I31[i],  I32[i],  I33[i],  J00[i],  J01[i],  J02[i],  J10[i],  J11[i],  J20[i],  K00[i],  Ks00[i], K01[i],  Ks01[i], Ks02[i], K10[i],  Ks10[i], K11[i],  Ks11[i], K20[i],  Ks20[i], K30[i],  Ks30[i], SIGMA_3[i],Intg_norm[i]))
    outfile.close()
    OUT=np.loadtxt(out_dir)    
    return OUT.T

def Param_Estimate(fit_minK,fit_maxK,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,k_mocks,Pk_mocks,PT,strategy,PS_type,fit_tech,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo):
    print( ' ')
    print( 'Important: make sure the mocks should have the same k-bins as the data!')
    print( 'Important: make sure: sigma8_fid = sigma8_fid_integ !')
    print( ' ')
    print( 'PS_type  = ',PS_type)
    print( 'Nparams=',Nparms)
# 6.1 choosing fitting points:---------------------------
    if(PS_type=='den+mom'):
      if(not Domultipo):
        K_OBS=np.zeros((2*len(k_obs)))
        K_OBS[0:len(k_obs)]=k_obs
        K_OBS[len(k_obs):2*len(k_obs)]=k_obs
        ind_fit=np.where((K_OBS>=fit_minK) & (K_OBS<=fit_maxK))
        #------- 
        K_MOCK=np.zeros((2*len(k_mocks)))
        K_MOCK[0:len(k_mocks)]=k_mocks
        K_MOCK[len(k_mocks):2*len(k_mocks)]=k_mocks
        ind_mock_fit=np.where((K_MOCK>=fit_minK) & (K_MOCK<=fit_maxK))
        Pk_mocks_fit=Pk_mocks[ind_mock_fit[0],:] 
      if(Domultipo):
        K_OBS=k_obs
        ind_fit=np.where((K_OBS>=fit_minK) & (K_OBS<=fit_maxK))
        #------- 
        K_MOCK =k_mocks
        ind_mock_fit=np.where((K_MOCK>=fit_minK) & (K_MOCK<=fit_maxK))
        Pk_mocks_fit=Pk_mocks[ind_mock_fit[0],:]        
    else:
        ind_fit=np.where((k_obs>=fit_minK) & (k_obs<=fit_maxK))    
        ind_mock_fit=np.where((k_mocks>=fit_minK) & (k_mocks<=fit_maxK))
        Pk_mocks_fit=Pk_mocks[ind_mock_fit[0],:]
    Nk = len(Pk_obs[ind_fit])
    Nmock = len(Pk_mocks_fit[0,:]) 

# 6.1 chi2 minimization:---------------------------------
    if(fit_tech=='Chi2'): 
        print( 'fit_tech = ',fit_tech  )
        # inverse covaraince matrix:
        Cov  = np.cov(Pk_mocks_fit)
        pivots = np.zeros(len(Cov[:,1]), np.intc)
        identity = np.eye(len(Cov[:,1]))
        Cov_cov_lu, pivots, Cov_inv, info = lapack.dgesv(Cov, identity)
        # 6.3.1 Optimize: 
        if(strategy=='Optimize'):
            print( 'Optimize')
            if(PS_type=='mom'):
                Nparms=5
                if(Damp_type=='sep'):
                    outpf    = sp.optimize.minimize(CHI2,[0.8, 0.38, 0.72, 25.0, 25.0,25.0],args=(ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v1 =outpf.x[3]
                    sigma_v2 =outpf.x[4]
                    sigma_v3 =outpf.x[5]
                    paramsss = [b1sigma8, fsigma8, b2sigma8, sigma_v1,sigma_v2,sigma_v3]
                    chisq    = CHI2(paramsss,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
                    return fsigma8, b1sigma8,  b2sigma8, sigma_v1,sigma_v2,sigma_v3,chisq
                else:
                    outpf    = sp.optimize.minimize(CHI2,[0.8, 0.38, 0.72, 25.0],args=(ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v =outpf.x[3]
                    paramsss = [b1sigma8, fsigma8, b2sigma8, sigma_v]
                    chisq    = CHI2(paramsss,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
                    return fsigma8, b1sigma8,  b2sigma8, sigma_v,chisq
            if(PS_type=='den'):
                Nparms=5
                if(Damp_type=='sep'):                
                    outpf    = sp.optimize.minimize(CHI2,[0.8, 0.38, 0.72, 25.0, 25.0,25.0],args=(ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v1 =outpf.x[3]
                    sigma_v2 =outpf.x[4]
                    sigma_v3 =outpf.x[5]
                    paramsss = [b1sigma8, fsigma8, b2sigma8, sigma_v1,sigma_v2,sigma_v3]
                    chisq    = CHI2(paramsss,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
                    return fsigma8, b1sigma8,  b2sigma8, sigma_v1,sigma_v2,sigma_v3,chisq
                else:
                    outpf    = sp.optimize.minimize(CHI2,[0.8, 0.38, 0.72, 25.0],args=(ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v =outpf.x[3]
                    paramsss = [b1sigma8, fsigma8, b2sigma8, sigma_v]
                    chisq    = CHI2(paramsss,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
                    return fsigma8, b1sigma8,  b2sigma8, sigma_v,chisq
            if(PS_type=='den+mom'):
              if(Nparms==8):
                if(Damp_type=='sep'):                  
                    outpf    = sp.optimize.minimize(CHI2,[1.15, 0.38, 0.44, 25.0, 25.5, 25.0, 1.15, 0.44, 25.0, 25.5, 25.0],args=(ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v1 =outpf.x[3]
                    sigma_v2 =outpf.x[4]
                    sigma_v3 =outpf.x[5]
                    b1vsigma8=outpf.x[6]
                    b2vsigma8=outpf.x[7]
                    sigmav_v1=outpf.x[8]
                    sigmav_v2=outpf.x[9]
                    sigmav_v3=outpf.x[10]
                    paramsss = [b1sigma8, fsigma8, b2sigma8,sigma_v1,sigma_v2,sigma_v3,b1vsigma8,b2vsigma8,sigmav_v1,sigmav_v2,sigmav_v3]
                    chisq    = CHI2(paramsss,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
                    return fsigma8, b1sigma8,b2sigma8,sigma_v1,sigma_v2,sigma_v3,b1vsigma8,b2vsigma8,sigmav_v1,sigmav_v2,sigmav_v3,chisq
                else:
                    outpf    = sp.optimize.minimize(CHI2,[1.15, 0.38, 0.44, 25.0, 1.15, 0.44, 25.0],args=(ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v  =outpf.x[3]
                    b1vsigma8=outpf.x[4]
                    b2vsigma8=outpf.x[5]
                    sigmav_v =outpf.x[6]
                    paramsss = [b1sigma8, fsigma8, b2sigma8,sigma_v,b1vsigma8,b2vsigma8,sigmav_v]
                    chisq    = CHI2(paramsss,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
                    return fsigma8, b1sigma8,b2sigma8,sigma_v,b1vsigma8,b2vsigma8,sigmav_v,chisq
              if(Nparms==5):
                if(Damp_type=='sep'):                  
                    outpf    = sp.optimize.minimize(CHI2,[0.8, 0.38, 0.72, 25.0, 25.0,25.0],args=(ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v1 =outpf.x[3]
                    sigma_v2 =outpf.x[4]
                    sigma_v3 =outpf.x[5]
                    paramsss = [b1sigma8, fsigma8, b2sigma8, sigma_v1,sigma_v2,sigma_v3]
                    chisq    = CHI2(paramsss,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
                    return fsigma8, b1sigma8,  b2sigma8, sigma_v1,sigma_v2,sigma_v3,chisq
                else:                  
                    outpf    = sp.optimize.minimize(CHI2,[0.8, 0.38, 0.72, 25.0],args=(ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v =outpf.x[3]
                    paramsss = [b1sigma8, fsigma8, b2sigma8, sigma_v]
                    chisq    = CHI2(paramsss,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo)
                    return fsigma8, b1sigma8,  b2sigma8, sigma_v,chisq
        #6.3.2 MCMC:
        if(strategy=='MCMC'):
          print( 'MCMC' )
          if(Damp_type=='sep'):            
            if(PS_type=='mom') or (PS_type=='den'):
                Nparms=5
                ndim, nwalkers = 6, 30
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
            if(PS_type=='den+mom'):
              if(Nparms==8):
                ndim, nwalkers = 11, 30
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
              if(Nparms==5):
                ndim, nwalkers = 6, 30
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
            sampler = emcee.EnsembleSampler(nwalkers, ndim, lnpost_chi2, args=[ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo])
            pos, prob, state = sampler.run_mcmc(begin, 500)
            sampler.reset()
            sampler.run_mcmc(pos, 500)
            return sampler.flatchain
          else:            
            if(PS_type=='mom') or (PS_type=='den'):
                Nparms=5
                ndim, nwalkers = 4, 30
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
            if(PS_type=='den+mom'):
              if(Nparms==8):
                ndim, nwalkers = 7, 30
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
              if(Nparms==5):
                ndim, nwalkers = 4, 30
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
            sampler = emcee.EnsembleSampler(nwalkers, ndim, lnpost_chi2, args=[ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo])
            pos, prob, state = sampler.run_mcmc(begin, 500)
            sampler.reset()
            sampler.run_mcmc(pos, 500)
            return sampler.flatchain
# 6.4 Box-Cox:-------------------------------------------
    if(fit_tech=='BC'):
        print( 'fit_tech = ',fit_tech)
        Pk_obs = Pk_obs[ind_fit]
        lmbdas = np.linspace(-1, 1,150)
        llf    = np.zeros(lmbdas.shape, dtype=np.float)
        BC_nu  = np.zeros(Nk)
        BC_d   = np.zeros(Nk)
        for ik in range(Nk):
            if(min(Pk_mocks_fit[ik,:]) <=0.0):
                BC_d[ik]=abs( min(Pk_mocks_fit[ik,:]) )+0.01*(max(Pk_mocks_fit[ik,:])-min(Pk_mocks_fit[ik,:]))
            if(min(Pk_mocks_fit[ik,:]) >0.0):
                BC_d[ik]=0.0
            for ii, lmbda in enumerate(lmbdas):
                llf[ii] = stats.boxcox_llf(lmbda, Pk_mocks_fit[ik,:]+BC_d[ik])
            BC_nu[ik]=lmbdas[llf==max(llf)]
            if(  (Pk_obs[ik]+BC_d[ik])>0.0  ):
                Pk_obs[ik]     = (( Pk_obs[ik]         + BC_d[ik] )**BC_nu[ik]-1.0)/BC_nu[ik]
            else:
                print( '======-----------   ********   -------------=====')
                print( 'Warning: Pk+delta<0, the results may be biased!!!')
                print( 'please increasing the BC_d by increasing 0.01 to a larger value!!')
                print( '======-----------   ********   -------------=====')
                Pk_obs[ik]     = (-abs( Pk_obs[ik]     + BC_d[ik] )**BC_nu[ik]-1.0)/BC_nu[ik]
            Pk_mocks_fit[ik,:] = (( Pk_mocks_fit[ik,:] + BC_d[ik] )**BC_nu[ik]-1.0)/BC_nu[ik]
        # inverse covaraince matrix:
        Cov  = np.cov(Pk_mocks_fit)
        pivots = np.zeros(len(Cov[:,1]), np.intc)
        identity = np.eye(len(Cov[:,1]))
        Cov_cov_lu, pivots, Cov_inv, info = lapack.dgesv(Cov, identity)        
        #Cov_inv_hat = Cov_inv#(Nmock-Nk-2.0)/(Nmock-1.0) * Cov_inv
        #det=np.linalg.det(Cov)
        #Cp=det**(-0.5)*((Nmock-1)*math.pi)**(-Nk/2.0)*(sp.special.gamma( Nmock/2.0 ))/(sp.special.gamma( (Nmock-Nk)/2.0 ))
        Cp=1.0
        # 6.4.1 Optimize:        
        if(strategy=='Optimize'):            
            print( 'Optimize')
            if(PS_type=='mom'):
                Nparms=5
                if(Damp_type=='sep'):
                    outpf    = sp.optimize.minimize(Box_CoxFUN,[0.8, 0.38, 0.72, 25.0, 25.0, 25.0],args=(Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v1 =outpf.x[3]
                    sigma_v2 =outpf.x[4]
                    sigma_v3 =outpf.x[5]
                    return fsigma8, b1sigma8,  b2sigma8,sigma_v1,sigma_v2,sigma_v3,'N/A'
                else:
                    outpf    = sp.optimize.minimize(Box_CoxFUN,[0.8, 0.38, 0.72, 25.0],args=(Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v  =outpf.x[3]
                    return fsigma8, b1sigma8,  b2sigma8,sigma_v,'N/A'
            if(PS_type=='den'):
                Nparms=5
                if(Damp_type=='sep'):                
                    outpf    = sp.optimize.minimize(Box_CoxFUN,[0.8, 0.38, 0.72, 25.0, 25.0, 25.0],args=(Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v1 =outpf.x[3]
                    sigma_v2 =outpf.x[4]
                    sigma_v3 =outpf.x[5]
                    return fsigma8, b1sigma8,  b2sigma8,sigma_v1,sigma_v2,sigma_v3,'N/A'
                else:                
                    outpf    = sp.optimize.minimize(Box_CoxFUN,[0.8, 0.38, 0.72, 25.0],args=(Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v =outpf.x[3]
                    return fsigma8, b1sigma8,  b2sigma8,sigma_v,'N/A'
            if(PS_type=='den+mom'):
              if(Nparms==8):
                if(Damp_type=='sep'):  
                    outpf    = sp.optimize.minimize(Box_CoxFUN,[1.15, 0.38, 0.44, 25.0, 25.5, 25.0, 1.15, 0.44, 25.0, 25.5, 25.0],args=(Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v1 =outpf.x[3]
                    sigma_v2 =outpf.x[4]
                    sigma_v3 =outpf.x[5]
                    b1vsigma8=outpf.x[6]
                    b2vsigma8=outpf.x[7]
                    sigmav_v1=outpf.x[8]
                    sigmav_v2=outpf.x[9]
                    sigmav_v3=outpf.x[10]
                    return fsigma8, b1sigma8, b2sigma8,sigma_v1,sigma_v2,sigma_v3,b1vsigma8,b2vsigma8,sigmav_v1,sigmav_v2,sigmav_v3,'N/A'
                else:  
                    outpf    = sp.optimize.minimize(Box_CoxFUN,[1.15, 0.38, 0.44, 25.0, 1.15, 0.44, 25.0],args=(Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v  =outpf.x[3]
                    b1vsigma8=outpf.x[4]
                    b2vsigma8=outpf.x[5]
                    sigmav_v =outpf.x[6]
                    return fsigma8, b1sigma8, b2sigma8,sigma_v,b1vsigma8,b2vsigma8,sigmav_v,'N/A'
              if(Nparms==5):
                if(Damp_type=='sep'):                  
                    outpf    = sp.optimize.minimize(Box_CoxFUN,[0.8, 0.38, 0.72, 25.0, 25.0, 25.0],args=(Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v1 =outpf.x[3]
                    sigma_v2 =outpf.x[4]
                    sigma_v3 =outpf.x[5]
                    return fsigma8, b1sigma8,  b2sigma8,sigma_v1,sigma_v2,sigma_v3,'N/A'
                else:                  
                    outpf    = sp.optimize.minimize(Box_CoxFUN,[0.8, 0.38, 0.72, 25.0],args=(Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo),method='Nelder-Mead',tol=10.**(-11))
                    b1sigma8 =outpf.x[0]
                    fsigma8  =outpf.x[1]
                    b2sigma8 =outpf.x[2]
                    sigma_v =outpf.x[3]
                    return fsigma8, b1sigma8,  b2sigma8,sigma_v,'N/A'
        #6.3.2 MCMC: 
        if(strategy=='MCMC'):
          print( 'MCMC')
          if(Damp_type=='sep'):            
            if(PS_type=='mom') or (PS_type=='den'):
                Nparms=5
                ndim, nwalkers = 6, 34
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
            if(PS_type=='den+mom'):
              if(Nparms==8):
                ndim, nwalkers = 11, 34
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
              if(Nparms==5):
                ndim, nwalkers = 6, 34
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
            sampler = emcee.EnsembleSampler(nwalkers, ndim, lnpost_bc, args=[Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo])
            pos, prob, state = sampler.run_mcmc(begin, 2000)
            sampler.reset()
            sampler.run_mcmc(pos, 100000)
            return sampler.flatchain          
          else:            
            if(PS_type=='mom') or (PS_type=='den'):
                Nparms=5
                ndim, nwalkers = 4, 34
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
            if(PS_type=='den+mom'):
              if(Nparms==8):
                ndim, nwalkers = 7, 34
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
              if(Nparms==5):
                ndim, nwalkers = 4, 34
                begin = [[(0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0),
                          (0.1*(np.random.rand()-0.5)+1.0)] for i in range(nwalkers)]
            sampler = emcee.EnsembleSampler(nwalkers, ndim, lnpost_bc, args=[Nk,Nmock,Cp,BC_d,BC_nu,ind_fit,Sig8_fid,kmod_conv,k_obs,Pk_obs,WF_Kobs_Kmod,WF_rand,Cov_inv,PT,PS_type,Nparms,Growthz,Damp_type,WFCon_type,Domultipo,Nmnpo])
            pos, prob, state = sampler.run_mcmc(begin, 1500)
            sampler.reset()
            sampler.run_mcmc(pos, 10000)
            return sampler.flatchain             
# The end.
#==========================================================================