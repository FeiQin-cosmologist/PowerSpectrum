#==========================================================================
#
#                                  CODE
#
#--------------------------------------------------------------------------
# 1. INITIAL SETTING:
import math
import numpy as np
import scipy as sp
from scipy import interpolate


#============================================  
def WF_CONV(Ki,Kj,WF_rand,Ncosa,epsilon_par):  
    dcosa=2.0/ Ncosa   
    Nki=len(Ki)  ;  #ki_min=min(Ki)  ;  ki_max=max(Ki)      
    Nkj=len(Kj)  ;  kj_min=min(Kj)  ;  kj_max=max(Kj)   
    WF_kikj=np.zeros((Nki,Nkj))  #WF_kikj[KI,KJ]
    
    WF_rand[0][0]=0.0  ;  WF_rand[1][0]=1.0
    Pwin_spline = sp.interpolate.splrep(WF_rand[0],WF_rand[1], s=0) 
    
    Neps=epsilon_par[2];  eps_min=epsilon_par[0];  eps_max=epsilon_par[1]
    deps=(eps_max-eps_min)/Neps
    # https://wenku.baidu.com/view/719b47fa0740be1e640e9a97.html
    cosa=np.zeros((Ncosa+1))
    for i_cosa in range(Ncosa+1):
        cosa[i_cosa]=-1.0+i_cosa*dcosa
        
    eps=np.zeros((Neps+1))
    for i_eps in range(Neps+1):
        eps[i_eps]=eps_min+i_eps*deps
    Pwin = sp.interpolate.splev(eps, Pwin_spline, der=0)
    
    for i in range(Nki):
       FUN=np.zeros(  (Nkj,Neps+1,Ncosa+1)  )# FUN[Nkj,Neps+1,Ncosa+1]
       for i_eps in range(Neps+1):  
          for i_cosa in range(Ncosa+1):
             if (np.abs(Ki[i]**2+eps[i_eps]**2-2.0*Ki[i]*eps[i_eps]*cosa[i_cosa])<10.e-15) and (cosa[i_cosa]==1.0):
                 R_eps=0.0
             else:
                 R_eps= np.sqrt(Ki[i]**2+eps[i_eps]**2-2.0*Ki[i]*eps[i_eps]*cosa[i_cosa])
             bins = int( Nkj*(R_eps-kj_min)/(kj_max-kj_min) )
             if((bins >= 0) and (bins <Nkj)): 
                 FUN[bins,i_eps,i_cosa]= eps[i_eps]* eps[i_eps] * Pwin[i_eps]  
       #--------------------           
       for j in range(Nkj):    
          F1=FUN[j,0,0]+FUN[j,Neps,0]+FUN[j,0,Ncosa]+FUN[j,Neps,Ncosa] 
          F2=sum(FUN[j,:,0])    
          F3=sum(FUN[j,:,Ncosa])    
          F4=sum(FUN[j,0,:])    
          F5=sum(FUN[j,Neps,:]) 
          F6=sum(sum(FUN[j,1:Neps,1:Ncosa]))
          #F6=0.
          #for i_eps in range(Neps-1): 
          #   for i_cosa in range(Ncosa-1):
          #      F6=F6+FUN[j,i_eps+1,i_cosa+1]
          WF_kikj[i,j]=deps*dcosa*(0.25*F1+0.5*(F2+F3+F4+F5)+F6)           
    
    # normalization WF_kikj[i,j]:
    for i in range(len(WF_kikj[:,1])):
        WF_kikj[i,:]=WF_kikj[i,:]/sum(WF_kikj[i,:])
        
    return WF_kikj

#============================================

def Pk_CONV(Ki,WFkikj,Pkj,k_random,WF_random):    
    
    Psum=np.zeros(len(Ki))
    for i in range(len(Psum)):
        Psum[i]=sum(WFkikj[i,:]*Pkj)

    Pwin_spline = sp.interpolate.splrep(k_random,WF_random, s=0)
    PwinKi  = sp.interpolate.splev(Ki, Pwin_spline, der=0)
    Pwin0 = sp.interpolate.splev(0.0, Pwin_spline, der=0)

    P0 = sum(WFkikj[0,:]*Pkj) / Pwin0
    Pm = Psum - P0*PwinKi
    return Pm


#============================================