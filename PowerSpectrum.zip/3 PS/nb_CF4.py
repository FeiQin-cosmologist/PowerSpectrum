import numpy as np
import math
import matplotlib.pyplot as plt
from CosmoFunc import *
from astropy import units as u
from astropy.coordinates import SkyCoord
from FQin import *
 

 



def nb_cf4(raR, decR, zR,OmegaM,OmegaA,Hub, nzbin,zmx):
    c = SkyCoord(ra=raR, dec=decR, unit=(u.degree, u.degree))
    x = c.galactic ; lR = np.asarray( x.l) ; bR = np.asarray(x.b)
    # belt 1
    ind1=np.zeros(len(raR),dtype=bool)
    ind0=np.where((decR<=36.2)&(decR>=-0.155)&(raR  >=111 ) & ( raR  <=250 ))[0]
    ind1[ind0]=True
    # belt 2
    ind2=np.zeros(len(raR),dtype=bool)
    ind0=np.where((decR<=36.2)&(decR>=-0.155)&( raR <=48. ) )[0]
    ind2[ind0]=True
    ind3=np.zeros(len(raR),dtype=bool)
    ind0=np.where((decR<=36.2)&(decR>=-0.155)&( raR >=325.5 ) )[0]
    ind3[ind0]=True
    # whole belt 
    ind=ind1+ind2+ind3
    # belt area 
    Sbelt = 2.0*math.pi - 2.0*math.pi*(1.0-np.cos((90.-36.2)/180.0*math.pi))  
    Sbelt1 = Sbelt* ( (250-111) )/360.
    Sbelt2 = Sbelt* ((360-325.5)+48. )/360.
    # nb belt
    nb    = np.zeros(len(zR))        
    nb1   = nbar_compute(0.002,zR[ind1],Sbelt1 ,OmegaM,OmegaA,Hub, nzbin,zmx)         
    nb[ind1]=nb1        
    nb2   = nbar_compute(0.002,zR[ind2+ind3],Sbelt2 ,OmegaM,OmegaA,Hub, nzbin,zmx)         
    nb[ind2+ind3]=nb2   
    # Other area
    Ind=np.ones(len(raR),dtype=bool)
    inds=np.where((lR>149)&(lR<255)&(np.abs(bR)<7))[0]
    Ind[inds]=False
    Ind[ind]=False  
    # area
    Smw=2*(2.0*math.pi - 2.0*math.pi*(1.0-np.cos(83./180.0*math.pi)) ) 
    s1=4.0*math.pi - 2.0*math.pi*(1.0-np.cos(45./180.0*math.pi))
    s2=  2.0*math.pi*(1.0-np.cos(45./180.0*math.pi))
    S1=  (4.0*math.pi - Smw) * s1 /  (4.0*math.pi) - Sbelt1- Sbelt2
    S2=  (4.0*math.pi - Smw) * s2 /  (4.0*math.pi)
    # Other area 1
    idn=np.where(decR[Ind]>=-45.)[0]
    nb1   = nbar_compute(0.002,zR[Ind][idn],S1 ,OmegaM,OmegaA,Hub, nzbin,zmx) 
    temp= nb[Ind] 
    temp[idn]=nb1       
    nb[Ind] = temp
    # Other area 2
    idn2=np.where(decR[Ind]<-45.)[0]
    nb2   = nbar_compute(0.002,zR[Ind][idn2],S2 ,OmegaM,OmegaA,Hub, nzbin,zmx) 
    temp2=  nb[Ind]
    temp2[idn2]=nb2     
    nb[Ind] = temp2
    # milky way
    Indmw=np.zeros(len(raR),dtype=bool)
    inds=np.where((lR>149)&(lR<255)&(np.abs(bR)<7))[0]
    Indmw[inds]=True
    nbmw   = nbar_compute(0.002,zR[Indmw],Smw ,OmegaM,OmegaA,Hub, nzbin,zmx)         
    nb[Indmw]=nbmw 

    '''plt.scatter(raR[Indmw],decR[Indmw],s=0.0001);
    plt.scatter(raR[Ind][idn2],decR[Ind][idn2],s=0.0001);
    plt.scatter(raR[Ind][idn],decR[Ind][idn],s=0.0001);
    plt.scatter(raR[ind2+ind3],decR[ind2+ind3],s=0.0001);
    plt.scatter(raR[ind1],decR[ind1],s=0.0001);
    #---------------------------------------------------
    plt.scatter(zR[Indmw],nb[Indmw],s=0.1);
    plt.scatter(zR[Ind][idn2],nb[Ind][idn2],s=0.1);
    plt.scatter(zR[Ind][idn],nb[Ind][idn],s=0.1);
    plt.scatter(zR[ind2+ind3],nb[ind2+ind3],s=0.1);
    plt.scatter(zR[ind1],nb[ind1],s=0.1);'''
    return nb






